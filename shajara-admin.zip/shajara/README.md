# Oila shajarasi — sayt + boshqaruv paneli

Cloudflare Worker (bepul) + D1 bazasi. Sayt — faqat ko‘rish uchun; **barcha ma’lumot va sozlamalar `/admin` boshqaruv panelidan o‘zgartiriladi.**

| Manzil | Nima |
|---|---|
| `/` | Shajara sayti (daraxt, doira, ro‘yxat, eksport) — mehmonlar uchun |
| `/admin` | Boshqaruv paneli — parol bilan |

## Boshqaruv panelida nimalar o‘zgartiriladi

- **Insonlar** — ism, familiya, otasining ismi, jinsi, tug‘ilgan/vafot sanasi va joyi, dafn joyi, kasbi, tarjimai hol, surat (kesib olish bilan), ota-ona, turmush o‘rtoqlari, farzandlar, «Saytda ko‘rsatilsin» (yashirish), faqat admin ko‘radigan izoh. Qidiruv, filtrlar, guruhli yashirish/o‘chirish.
- **Bosh sahifa** — statistika, «Tekshirish kerak» ro‘yxati (yili yo‘q, suratsiz, bog‘lanmagan, yoshi mos kelmaydigan…), so‘nggi o‘zgarishlar.
- **Sayt sozlamalari** — sayt nomi, shior, havola tavsifi, plakat epigrafi, boshlang‘ich ko‘rinish, yozuv (lotin/kirill), avlod boshi, «yaqin sanalar» oralig‘i, plakat standartlari va 14 ta bo‘lim/tugmani yoqish-o‘chirish.
- **Ko‘rinish** — rang rejimi, yorug‘ va qorong‘i mavzu uchun 9 tadan rang, tayyor palitralar, fon rasmi (yuklash, joylashuv), logotip.
- **Matnlar** — saytdagi har bir yozuv (130+ ta) qayta yoziladi.
- **Maxfiylik** — saytni ko‘rish paroli bilan yopish, tirik insonlarning qaysi ma’lumotlari mehmonlardan yashirilishi, qidiruv tizimlari.
- **Zaxira va import** — to‘liq zaxira (suratlar bilan), CSV (Excel), zaxiradan tiklash, ishlatilmagan suratlarni tozalash, hammasini o‘chirish.
- **Xavfsizlik** — admin parolini o‘zgartirish, boshqa qurilmalardan chiqarish, kirishlar tarixi.
- **O‘zgarishlar tarixi** — kim qo‘shildi, nima o‘zgardi (oxirgi 1000 ta amal).

## Bir martalik sozlash

1. **Workers & Pages → Create → Import a repository** → shu repozitoriy.
   Build command: `npm run build`, Deploy command: `npx wrangler deploy`.
2. D1 bazasi (`shajara-db`, binding `DB`) birinchi deployda avtomatik yaratiladi; jadvallar sayt birinchi ochilganda yaratiladi. Eski versiyadagi ma’lumotlar o‘z joyida qoladi va yangi panelda darhol ko‘rinadi.
3. Worker → **Settings → Variables and Secrets** → Type **Secret**:
   - `ADMIN_PASSWORD` — birinchi kirish paroli (kamida 12 belgi).
   - `BACKUP_TOKEN` — ixtiyoriy, haftalik zaxira uchun (kamida 16 belgi).
4. `https://<sayt>/admin` → parol bilan kiring → **Xavfsizlik** bo‘limida o‘z parolingizni o‘rnating. Shundan keyin `ADMIN_PASSWORD` ishlamaydi (parol bazada PBKDF2 bilan shifrlangan holda saqlanadi).

### Parolni unutsangiz
Panel paroli bazadan o‘chiriladi va yana `ADMIN_PASSWORD` ishlay boshlaydi:
```
npx wrangler d1 execute shajara-db --remote --command "UPDATE meta SET data = json_remove(data, '$.hash', '$.salt', '$.iter') WHERE k = 'auth'"
```

### Haftalik avtomatik zaxira
GitHub → **Settings → Secrets and variables → Actions**: `SITE_URL` (sayt manzili) va `BACKUP_TOKEN` (Cloudflare’dagi bilan bir xil). Har yakshanba `backup/shajara-zaxira.json` yangilanadi. **Repozitoriy maxfiy (private) bo‘lsin** — zaxirada shaxsiy ma’lumotlar bor.

## Dasturchi uchun

- `public/index.html` — sayt (faqat ko‘rish). Bosh sahifa Worker orqali o‘tadi: sarlavha, ranglar va ma’lumotlar serverda sahifaga qo‘shiladi (`src/worker.js`).
- `public/admin.html`, `public/admin.js` — boshqaruv paneli.
- `public/config.js` — standart sozlamalar, ranglar, barcha matnlar. Sayt, panel va server bir xil faylni ishlatadi.
- `src/api.js` — API (D1): insonlar, sozlamalar, suratlar, zaxira, parollar, jurnal. Ota-ona/turmush o‘rtog‘i aloqalari server tomonda izchil saqlanadi.
- `src/blob.js` — suratlar (`/_blob/<id>`), sayt yopiq bo‘lsa parolsiz berilmaydi.
- Mahalliy sinov: `npm i && npm run dev` → http://localhost:8788/admin (sinov paroli: `sinov12345`).
- Bepul tarif chegaralari hisobga olingan: surat ≤ 1,4 MB (D1 qatori 2 MB), parol xeshi 10 000 PBKDF2 iteratsiya (10 ms CPU).
