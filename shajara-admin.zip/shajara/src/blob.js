// Suratlarni D1 bazasidan berish: /_blob/<id>
import { init, whoIs } from "./api.js";

export async function onRequestGet({ request, params, env }) {
  const id = String(params.id || "");
  if (!/^[a-f0-9]{32}$/.test(id) || !env.DB) return new Response("Not found", { status: 404 });
  let row = null, locked = false;
  try {
    await init(env);
    const w = await whoIs(request, env);
    if (!w.viewOk) return new Response("Locked", { status: 401 });
    locked = w.locked;
    row = await env.DB.prepare("SELECT type, b64 FROM photos WHERE id = ?").bind(id).first();
  } catch (e) { row = null; }
  if (!row) return new Response("Not found", { status: 404 });
  const bin = atob(row.b64), u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return new Response(u, { headers: {
    "content-type": row.type,
    "cache-control": (locked ? "private" : "public") + ", max-age=31536000, immutable",
    "x-content-type-options": "nosniff"
  } });
}
