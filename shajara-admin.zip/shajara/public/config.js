/* Shajara — umumiy sozlamalar: standart qiymatlar, ranglar, matnlar.
   Bu fayl ham sahifada (window.SJ_CONFIG), ham serverda (globalThis.SJ_CONFIG) ishlatiladi. */
(function (root) {
  "use strict";

  /* ---------- Sayt sozlamalarining standart qiymatlari ---------- */
  const DEFAULTS = {
    title: "",                 // bo'sh bo'lsa — «Oila shajarasi» (Matnlar → defTitle)
    subtitle: "",              // sarlavha ostidagi qisqa matn
    description: "Oila shajarasi — avlodlar daraxti",
    epigraph: "",              // plakatdagi epigraf; bo'sh bo'lsa — Matnlar → epiDefault
    rootId: null,              // standart «avlod boshi»
    meId: null,                // admin saytni ochganda «Siz» deb belgilanadigan inson
    defaultView: "tree",       // tree | fan | list
    defaultScript: "lat",      // lat | cyr
    paged: "auto",             // auto | on | off  (daraxtni shoxlarga bo'lish)
    upcomingDays: 30,
    features: {
      fan: true, list: true, search: true, relations: true, yetti: true, upcoming: true,
      stats: true, script: true, legend: true, export: true, poster: true, calendar: true,
      backup: false, adminLink: true
    },
    privacy: {                 // tirik insonlar uchun mehmonlardan yashiriladi:
      birthDay: true, birthPlace: false, photo: false, occupation: false, bio: false,
      noindex: true            // qidiruv tizimlari indekslamasin
    },
    theme: { mode: "auto", light: {}, dark: {} },
    scene: { show: true, photoId: null, position: "62%" },
    logoPhotoId: null,
    poster: { paper: "A1", theme: "dark", photos: true },
    labels: {}
  };

  const ENUMS = {
    defaultView: ["tree", "fan", "list"],
    defaultScript: ["lat", "cyr"],
    paged: ["auto", "on", "off"],
    "theme.mode": ["auto", "light", "dark"],
    "scene.position": ["10%", "35%", "62%", "90%"],
    "poster.paper": ["A3", "A2", "A1", "A0", "auto"],
    "poster.theme": ["dark", "light"]
  };

  /* ---------- Ranglar: [kalit, nomi, yorug' standart, qorong'i standart] ---------- */
  const COLORS = [
    ["green",  "Asosiy rang (tugmalar, faol boʻlim)", "#1F4B3B", "#2F6E55"],
    ["gold",   "Oltin rang (aksent, belgilar)",       "#9C7128", "#D9B46A"],
    ["man",    "Erkaklar kartochkasi",                "#5E86AE", "#86A9D4"],
    ["woman",  "Ayollar kartochkasi",                 "#C47C86", "#DC9AA3"],
    ["branch", "Daraxt shoxlari (chiziqlar)",         "#B8954F", "#B9975A"],
    ["paper",  "Sahifa foni",                         "#EEE9DD", "#0C1220"],
    ["panel",  "Yon panel foni",                      "#FBF8F1", "#131C2E"],
    ["card",   "Kartochka foni",                      "#FFFDF8", "#18233A"],
    ["ink",    "Asosiy matn rangi",                   "#1E2A26", "#EEE8DA"]
  ];

  const isObj = v => v && typeof v === "object" && !Array.isArray(v);
  function merge(base, over) {
    const out = Array.isArray(base) ? base.slice() : { ...base };
    if (!isObj(over)) return out;
    for (const k of Object.keys(over)) {
      if (isObj(base[k]) && isObj(over[k])) out[k] = merge(base[k], over[k]);
      else if (over[k] !== undefined) out[k] = over[k];
    }
    return out;
  }
  const settingsOf = saved => merge(DEFAULTS, saved || {});
  const HEX = /^#[0-9a-fA-F]{6}$/, PID = /^[a-f0-9]{32}$/;

  /* Rang va fon sozlamalaridan CSS yasaydi (server sahifaga, admin esa ko'rib chiqishga qo'yadi). */
  function themeCss(s) {
    s = settingsOf(s);
    const block = (o) => {
      let css = "";
      for (const [k] of COLORS) {
        const v = o && o[k]; if (!HEX.test(v || "")) continue;
        css += `--${k}:${v};`;
        if (k === "green") css += `--green-soft:color-mix(in srgb,${v} 16%,var(--card));`;
        if (k === "gold") css += `--gold-btn:${v};--gold-soft:color-mix(in srgb,${v} 18%,var(--card));`;
        if (k === "man") css += `--man-soft:color-mix(in srgb,${v} 16%,var(--card));`;
        if (k === "woman") css += `--woman-soft:color-mix(in srgb,${v} 16%,var(--card));`;
        if (k === "card") css += `--surface:${v};`;
      }
      return css;
    };
    let css = "";
    const L = block(s.theme.light), D = block(s.theme.dark);
    if (L) css += `:root{${L}}`;
    if (D) css += `@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){${D}}}:root[data-theme="dark"]{${D}}`;
    const pos = ENUMS["scene.position"].includes(s.scene.position) ? s.scene.position : "62%";
    if (pos !== "62%") css += `.scene{background-position:center ${pos}!important}`;
    if (PID.test(s.scene.photoId || "")) css += `.scene{background-image:url("/_blob/${s.scene.photoId}")!important}`;
    if (s.scene.show === false) css += `.scene{display:none!important}`;
    return css;
  }

  /* ---------- Saytdagi barcha matnlar (Admin → Matnlar bo'limida o'zgartiriladi) ---------- */
  const LABELS = {
    defTitle: "Oila shajarasi", ppl: "kishi", gens: "avlod", viewTree: "Shajara daraxti", viewFan: "Doira ko'rinishi", viewList: "Oila a'zolari",
    genCount: "Avlodlar soni", pplOf: "{n} kishi", todayDates: "Bugungi sanalar", exportBtn: "Eksport",
    search: "Qidirish…", root: "Avlod boshi", center: "Markazda", pagedOn: "Shoxlar bo'yicha", pagedOff: "Butun daraxt",
    branchOf: "{n} shoxi", pageOf: "{i} / {n}", loading: "Shajara yuklanmoqda…", adminPanel: "Boshqaruv paneli", adminLogin: "Kirish",
    emptyVT: "Shajara hali to'ldirilmagan", emptyVP: "Shajara egasi ma'lumot kiritgach, bu yerda daraxt paydo bo'ladi.",
    errLoad: "Shajarani yuklab bo'lmadi. Internetni tekshirib, sahifani yangilang.", noName: "Ism kiritilmagan",
    lockTitle: "Shajara yopiq", lockText: "Bu oilaviy sahifa. Ko'rish uchun oila a'zolariga berilgan parolni kiriting.",
    lockPw: "Parol", lockBtn: "Ochish", lockErr: "Parol noto'g'ri.",
    tabInfo: "Ma'lumot", tabRel: "Qarindoshlar", forYou: "Siz uchun", bdate: "Tug'ilgan sana", bplace: "Tug'ilgan joyi",
    ddate: "Vafot etgan sana", dplace: "Dafn etilgan joyi", job: "Kasbi", age: "yosh", bioT: "Qisqacha ma'lumot",
    yetti: "Yetti ota", yettiHint: "ota tomondan ma'lum bo'g'in", parents: "Ota-onasi", spouse: "Turmush o'rtog'i",
    children: "Farzandlari", siblings: "Aka-uka, opa-singillari", inlaws: "Qayin tomoni", noRel: "Qarindoshlar hali kiritilmagan.",
    grand: "Nabira", great: "Evara", great2: "Chevara", isMe: "Bu — men", meClear: "Bu men emas",
    showFan: "Doirada ko'rish", showTree: "Daraxtda ko'rish", editInAdmin: "Tahrirlash", close: "Yopish",
    cmpLbl: "Boshqa inson bilan solishtirish", cmpFor: "uchun", relNone: "Qarindoshlik aloqasi kiritilmagan", none: "— tanlanmagan —",
    half_f: "ota bir", half_m: "ona bir",
    mePick: "Siz kimsiz?", meNone: "Kartochkada «Bu — men»", meRole: "Shajarada siz",
    meHint: "Shajarada o'zingizni bosing va «Bu — men» tugmasini tanlang — har bir inson siz uchun kimligi (amaki, xola, bobo…) ko'rsatiladi.",
    paternal: "Ota tomoni", maternal: "Ona tomoni", yettiLine: "Yetti ota chizig'i",
    stTotal: "Jami", stLiving: "Hayot", stDead: "Marhum", stGen: "Avlod", stMen: "Erkaklar", stWomen: "Ayollar",
    upTitle: "Yaqin sanalar", upSub: "keyingi {n} kun",
    upNone: "Keyingi {n} kunda tug'ilgan yoki xotira kunlari yo'q. Sanalar to'liq (kun va oy) kiritilganda bu yerda ko'rinadi.",
    allTitle: "Barcha insonlar", thName: "Ism-familiya", thRel: "Siz uchun", thBirth: "Tug'ilgan", thPlace: "Joyi", thDeath: "Vafot", thAge: "Yoshi",
    today: "Bugun", tomorrow: "Ertaga", inDays: "{n} kundan so'ng", evBirth: "Tug'ilgan kun", evBirthD: "Tavallud kuni", evDeath: "Xotira kuni",
    turns: "{n} yoshga to'ladi", yearsSince: "tavalludiga {n} yil", deathYears: "vafotiga {n} yil",
    months: "yanvar, fevral, mart, aprel, may, iyun, iyul, avgust, sentabr, oktabr, noyabr, dekabr",
    exTitle: "Eksport", tabPoster: "Plakat (SVG)", tabCal: "Kalendar", tabBackup: "Zaxira nusxa",
    pRoot: "Qaysi shajara", pPaper: "Qog'oz o'lchami", pTheme: "Rang", pDark: "Lojuvard", pLight: "Oq qog'oz", pPhotos: "Suratlar bilan",
    pTitle: "Sarlavha", pEpi: "Epigraf", pAuto: "Asl o'lcham", pMake: "Ko'rib chiqish", pSave: "SVG yuklab olish", pBuilding: "Plakat tayyorlanmoqda…",
    pReady: "Tayyor: {w}×{h} mm, {n} kishi, {k} KB. Matnlar vektor chiziqqa aylantirilgan — har qanday bosmaxonada aynan shunday chiqadi.",
    pReadyAuto: "Tayyor: {n} kishi, {k} KB. Matnlar vektor chiziqqa aylantirilgan — har qanday bosmaxonada aynan shunday chiqadi.",
    pErr: "Plakatni tayyorlab bo'lmadi: {e}", pHint: "Plakat vektor formatda: A0 o'lchamda ham xiralashmaydi. Bosmaxonaga SVG faylning o'zini bering.",
    epiDefault: "«Yetti otangni bil»", gen: "avlod", madeOn: "Tuzilgan sana",
    calIntro: "Qarindoshlaringizning tug'ilgan va xotira kunlari kalendaringizga tadbir sifatida tushadi. Kun va oyi kiritilgan sanalar olinadi.",
    calCount: "{n} ta sana olinadi · {m} kishida tug'ilgan sana to'liq emas", calCsv: "Google Calendar uchun (.csv)", calIcs: "Apple / Outlook uchun (.ics, zip ichida)",
    calSteps: "Google Calendar'ga qo'shish (kompyuterda)",
    calS1: "<b>calendar.google.com</b> ni oching → chapdagi «Boshqa kalendarlar» yonidagi <b>+</b> → «Yangi kalendar yaratish» → nomi: <b>Shajara</b>.",
    calS2: "<b>Sozlamalar → Import va eksport</b> → yuklab olgan <b>.csv</b> faylni tanlang → kalendar sifatida <b>Shajara</b>ni tanlang → <b>Import</b>.",
    calS3: "Sozlamalarda <b>Shajara</b> kalendarini oching → «Butun kunlik tadbirlar uchun bildirishnomalar» → <b>Shu kuni, 08:00</b> qo'shing. Endi har kuni ertalab telefoningizga eslatma keladi.",
    calS4: "Xohlasangiz, o'sha joyda «Boshqa bildirishnomalar → Kunlik kun tartibi»ni <b>Elektron pochta</b>ga qo'ying — har kuni ertalab xat ham keladi.",
    calNote: "CSV fayl keyingi 20 yil uchun har bir sanani yozadi va yoshni avtomatik ko'rsatadi. Yangi insonlar qo'shganingizda Shajara kalendarini o'chirib, qayta import qiling.",
    bkIntro: "Shajaraning ochiq qismini bitta faylga saqlab qo'yishingiz mumkin.", bkSave: "Zaxira nusxani yuklab olish (.json)",
    dlNo: "Bu ko'rinishda faylni yuklab olish mumkin emas.", dlOk: "Fayl saqlandi"
  };

  const LABEL_GROUPS = [
    ["Umumiy va menyu", ["defTitle","ppl","gens","viewTree","viewFan","viewList","genCount","pplOf","todayDates","exportBtn","search","root","center","pagedOn","pagedOff","branchOf","pageOf","loading","adminPanel","adminLogin"]],
    ["Bo'sh holat, xato va yopiq sahifa", ["emptyVT","emptyVP","errLoad","noName","lockTitle","lockText","lockPw","lockBtn","lockErr"]],
    ["Inson kartochkasi", ["tabInfo","tabRel","forYou","bdate","bplace","ddate","dplace","job","age","bioT","yetti","yettiHint","parents","spouse","children","siblings","inlaws","noRel","grand","great","great2","isMe","meClear","showFan","showTree","editInAdmin","close","cmpLbl","cmpFor","relNone","none","half_f","half_m"]],
    ["«Siz kimsiz?» bloki", ["mePick","meNone","meRole","meHint"]],
    ["Doira ko'rinishi", ["paternal","maternal","yettiLine"]],
    ["Ro'yxat va statistika", ["stTotal","stLiving","stDead","stGen","stMen","stWomen","upTitle","upSub","upNone","allTitle","thName","thRel","thBirth","thPlace","thDeath","thAge"]],
    ["Sanalar va eslatmalar", ["today","tomorrow","inDays","evBirth","evBirthD","evDeath","turns","yearsSince","deathYears","months"]],
    ["Eksport — plakat", ["exTitle","tabPoster","pRoot","pTitle","pEpi","epiDefault","pPaper","pAuto","pTheme","pDark","pLight","pPhotos","pMake","pSave","pBuilding","pReady","pReadyAuto","pErr","pHint","gen","madeOn"]],
    ["Eksport — kalendar", ["tabCal","calIntro","calCount","calCsv","calIcs","calSteps","calS1","calS2","calS3","calS4","calNote"]],
    ["Eksport — zaxira va yuklab olish", ["tabBackup","bkIntro","bkSave","dlNo","dlOk"]]
  ];
  const HTML_LABELS = ["calS1", "calS2", "calS3", "calS4"];

  root.SJ_CONFIG = { DEFAULTS, ENUMS, COLORS, LABELS, LABEL_GROUPS, HTML_LABELS, settingsOf, merge, themeCss };
})(typeof window !== "undefined" ? window : globalThis);
