/* Shajara — boshqaruv paneli (/admin). Barcha maʼlumot va sozlamalar shu yerdan oʻzgartiriladi. */
"use strict";
const C = window.SJ_CONFIG;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clone = v => JSON.parse(JSON.stringify(v));
const A = { people: new Map(), settings: C.settingsOf({}), photos: { count: 0, bytes: 0, orphans: 0 }, auth: {}, recent: [], rev: 0 };
const P = id => (id && A.people.get(id)) || null;

/* ================= Icons ================= */
const sv = (d, extra = "") => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${d}</svg>`;
const I = {
  home: sv('<path d="M3 11l9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>'),
  people: sv('<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.8-3.2 3-5 5.5-5s4.7 1.8 5.5 5"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14c2.5 0 4 1.5 4.5 4"/>'),
  settings: sv('<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>'),
  palette: sv('<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.6-.8 1.6-1.6 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-.9.7-1.6 1.6-1.6H16a5 5 0 0 0 5-5c0-4.1-4-7.4-9-7.4z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10" cy="7" r="1.2"/><circle cx="14.5" cy="7" r="1.2"/><circle cx="17" cy="10.5" r="1.2"/>'),
  text: sv('<path d="M4 6V4h16v2M12 4v16M9 20h6"/>'),
  lock: sv('<rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>'),
  backup: sv('<ellipse cx="12" cy="5.5" rx="7.5" ry="2.8"/><path d="M4.5 5.5v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-6M4.5 11.5v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-6"/>'),
  shield: sv('<path d="M12 3l7.5 3v5.5c0 4.6-3.2 8.3-7.5 9.5-4.3-1.2-7.5-4.9-7.5-9.5V6z"/><path d="M9 12l2 2 4-4"/>'),
  history: sv('<path d="M3.5 12a8.5 8.5 0 1 0 2.5-6"/><path d="M3.5 4v4h4M12 8v4l3 2"/>'),
  ext: sv('<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'),
  eye: sv('<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>'),
  out: sv('<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>'),
  plus: sv('<path d="M12 5v14M5 12h14"/>', 'stroke-width="2.3"'),
  search: sv('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
  trash: sv('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  x: sv('<path d="M6 6l12 12M18 6L6 18"/>', 'stroke-width="2.2"'),
  menu: sv('<path d="M4 7h16M4 12h16M4 17h16"/>', 'stroke-width="2.2"'),
  upload: sv('<path d="M12 16V4M7 9l5-5 5 5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>'),
  download: sv('<path d="M12 4v12M7 11l5 5 5-5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>'),
  reset: sv('<path d="M4 12a8 8 0 1 0 2.3-5.7"/><path d="M4 4v4h4"/>'),
  link: sv('<path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/>'),
  user: sv('<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>'),
  chev: sv('<path d="M9 6l6 6-6 6"/>')
};
const MARK = '<svg aria-hidden="true"><use href="#treeMark"/></svg>';

/* ================= Helpers ================= */
const MONTHS = C.LABELS.months.split(",").map(s => s.trim());
const pad2 = n => String(n).padStart(2, "0");
const capF = s => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
function parseDate(s) {
  s = String(s || "").trim(); if (!s) return null; let m;
  if ((m = s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/))) return { d: +m[1], m: +m[2], y: +m[3] };
  if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) return { d: +m[3], m: +m[2], y: +m[1] };
  if ((m = s.match(/^(\d{1,2})[.\/-](\d{4})$/))) return { d: null, m: +m[1], y: +m[2] };
  if ((m = s.match(/^(\d{1,2})[.\/-](\d{1,2})$/))) return { d: +m[1], m: +m[2], y: null };
  if ((m = s.match(/(\d{4})/))) return { d: null, m: null, y: +m[1] };
  return null;
}
function serDate(o) {
  if (!o) return ""; const { d, m, y } = o;
  if (d && m && y) return `${pad2(d)}.${pad2(m)}.${y}`; if (m && y) return `${pad2(m)}.${y}`; if (y) return String(y); if (d && m) return `${pad2(d)}.${pad2(m)}`; return "";
}
function fmtDate(s) {
  const o = parseDate(s); if (!o) return s || "";
  const parts = []; if (o.d && o.m) parts.push(o.d + " " + MONTHS[o.m - 1]); else if (o.m) parts.push(MONTHS[o.m - 1]); if (o.y) parts.push(o.y);
  return parts.join(" ");
}
const year = s => parseDate(s)?.y || "";
const isDead = p => !!(p.deceased || p.deathDate);
function yrs(p) {
  const b = year(p.birthDate), d = year(p.deathDate);
  if (b && d) return b + " – " + d; if (b && isDead(p)) return b + " – ?"; if (b) return String(b); if (d) return "? – " + d; return "";
}
function ageOf(p) {
  const b = parseDate(p.birthDate); if (!b?.y) return null;
  let end = new Date(); if (isDead(p)) { const d = parseDate(p.deathDate); if (!d?.y) return null; end = new Date(d.y, (d.m || 7) - 1, d.d || 1); }
  let a = end.getFullYear() - b.y;
  if (b.m) { const em = end.getMonth() + 1, ed = end.getDate(); if (em < b.m || (em === b.m && b.d && ed < b.d)) a--; }
  return a >= 0 && a < 130 ? a : null;
}
const short = p => [p.firstName, p.lastName].filter(Boolean).join(" ") || "(ismsiz)";
const full = p => [p.lastName, p.firstName, p.patronymic].filter(Boolean).join(" ") || "(ismsiz)";
const initials = p => ((p.firstName || "").charAt(0) + (p.lastName || "").charAt(0)).toUpperCase() || "?";
const photoSrc = p => p.photoId ? "/_blob/" + p.photoId : (p.photo || null);
function avatar(p, src) {
  src = src === undefined ? photoSrc(p) : src;
  return `<span class="av ${p.gender === "f" ? "f" : ""}${isDead(p) ? " dead" : ""}">${src ? `<img src="${esc(src)}" alt="" loading="lazy" onerror="this.remove()">` : esc(initials(p))}</span>`;
}
const whoHtml = (p, sub) => `<span class="who">${avatar(p)}<span><b>${esc(short(p))}</b><small>${esc(sub ?? (yrs(p) || p.patronymic || " "))}</small></span></span>`;
const bKey = p => { const b = parseDate(p?.birthDate); return b?.y ? b.y * 10000 + (b.m || 0) * 100 + (b.d || 0) : 99999999; };
const byName = (a, b) => short(a).localeCompare(short(b));
const kidsOf = id => [...A.people.values()].filter(p => p.fatherId === id || p.motherId === id).sort((a, b) => bKey(a) - bKey(b));
const spousesOf = p => (p?.spouses || []).map(P).filter(Boolean);
function siblingsOf(p) { const m = new Map(); for (const par of [p.fatherId, p.motherId]) if (P(par)) for (const k of kidsOf(par)) if (k.id !== p.id) m.set(k.id, k); return [...m.values()].sort((a, b) => bKey(a) - bKey(b)); }
function descendants(id) { const out = new Set(), q = [id]; while (q.length) { const x = q.pop(); for (const k of kidsOf(x)) if (!out.has(k.id)) { out.add(k.id); q.push(k.id); } } return out; }
function generations() {
  const memo = new Map();
  const g = (id, seen = new Set()) => { if (memo.has(id)) return memo.get(id); if (seen.has(id)) return 1; seen.add(id); const p = P(id); let v = 1; for (const x of [p.fatherId, p.motherId]) if (P(x)) v = Math.max(v, 1 + g(x, seen)); memo.set(id, v); return v; };
  let m = 0; for (const id of A.people.keys()) m = Math.max(m, g(id)); return m;
}
const patrOf = (fa, g) => fa?.firstName ? fa.firstName + (g === "f" ? " qizi" : " oʻgʻli") : "";
function fmtTime(ms) { const d = new Date(ms); return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`; }
const kb = n => n > 1048576 ? (n / 1048576).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
const genId = () => { const a = "abcdefghijklmnopqrstuvwxyz0123456789"; let s = ""; for (const b of crypto.getRandomValues(new Uint8Array(20))) s += a[b % 36]; return s; };
const norm = s => String(s || "").toLowerCase().replace(/[ʻʼ'‘’`]/g, "");
function toast(msg, bad) { const el = $("#toast"); el.textContent = msg; el.className = "toast" + (bad ? " bad" : ""); el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => el.hidden = true, bad ? 5200 : 3200); }
function download(name, data, type = "application/octet-stream") {
  const blob = data instanceof Blob ? data : new Blob([data], { type });
  const url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
}
const today = () => new Date().toISOString().slice(0, 10);

/* ================= API ================= */
async function api(path, { method = "GET", json, body, headers = {} } = {}) {
  const h = { "x-sj": "1", ...headers };
  if (json !== undefined) { h["content-type"] = "application/json"; body = JSON.stringify(json); }
  const r = await fetch(path, { method, headers: h, body, credentials: "same-origin", cache: "no-store" });
  let d = null; try { d = await r.json(); } catch (e) { }
  if (r.status === 403 && !/\/api\/(login|backup)/.test(path)) { guard = null; showLogin("Seans tugagan. Qaytadan kiring."); }
  if (!r.ok) { const e = new Error((d && d.error) || "Server xatosi (" + r.status + ")"); e.status = r.status; throw e; }
  return d;
}
async function reload() {
  const d = await api("/api/admin/data");
  A.people = new Map(d.people.map(p => [p.id, p])); A.settings = C.settingsOf(d.settings); A.rev = d.rev;
  A.photos = d.photos; A.auth = d.auth; A.recent = d.recent || [];
  renderNav();
}
async function uploadPhoto(blob, type) { return api("/api/photos", { method: "POST", body: blob, headers: { "content-type": type || blob.type || "image/jpeg" } }); }

/* ================= Modal helpers ================= */
function openModal(html, { wide } = {}) {
  const m = $("#modal"); m.innerHTML = `<div class="dlg"${wide ? ' style="width:min(720px,100%)"' : ""} role="dialog" aria-modal="true">${html}</div>`; m.hidden = false;
  const close = () => { m.hidden = true; m.innerHTML = ""; document.removeEventListener("keydown", onKey); };
  const onKey = e => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  m.onclick = e => { if (e.target === m) close(); };
  $$("[data-close]", m).forEach(b => b.onclick = close);
  return { el: m, close };
}
function confirmDlg({ title, text, ok = "Ha", danger = false, html = "" }) {
  return new Promise(res => {
    const { el, close } = openModal(`<div class="dlg-h"><h2>${esc(title)}</h2><button class="icon-btn" data-close aria-label="Yopish">${I.x}</button></div>
      <div class="dlg-b">${text ? `<p style="margin:0">${esc(text)}</p>` : ""}${html}</div>
      <div class="dlg-f"><button class="btn" data-close>Bekor qilish</button><button class="btn ${danger ? "danger solid" : "primary"}" id="cOk">${esc(ok)}</button></div>`);
    let done = false;
    $("#cOk", el).onclick = () => { done = true; close(); res(true); };
    const obs = new MutationObserver(() => { if (el.hidden) { obs.disconnect(); if (!done) res(false); } });
    obs.observe(el, { attributes: true, attributeFilter: ["hidden"] });
  });
}
function openPicker({ title, gender, exclude = [], allowNone = false, hint = "" }) {
  return new Promise(res => {
    const ex = new Set(exclude);
    const list = [...A.people.values()].filter(p => (!gender || p.gender === gender) && !ex.has(p.id)).sort(byName);
    const { el, close } = openModal(`<div class="dlg-h"><h2>${esc(title)}</h2><button class="icon-btn" data-close aria-label="Yopish">${I.x}</button></div>
      <div class="dlg-b">${hint ? `<p class="help">${esc(hint)}</p>` : ""}
        <div class="search" style="max-width:none">${I.search}<input class="in" id="pkQ" placeholder="Ism yoki familiya…" autocomplete="off"></div>
        <div class="plist-pick" id="pkL"></div></div>`);
    let picked = false;
    const draw = () => {
      const q = norm($("#pkQ", el).value.trim());
      const hits = list.filter(p => !q || norm(full(p)).includes(q)).slice(0, 250);
      $("#pkL", el).innerHTML = (allowNone && !q ? `<button data-id=""><span class="av" style="background:var(--sunk);color:var(--muted)">—</span><span>Tanlanmagan (olib tashlash)</span></button>` : "") +
        (hits.length ? hits.map(p => `<button data-id="${esc(p.id)}">${whoHtml(p, [yrs(p), p.patronymic].filter(Boolean).join(" · "))}</button>`).join("") : `<div class="empty">Hech kim topilmadi</div>`);
      $$("button[data-id]", $("#pkL", el)).forEach(b => b.onclick = () => { picked = true; close(); res(b.dataset.id || null); });
    };
    draw();
    $("#pkQ", el).oninput = draw;
    $("#pkQ", el).onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); const b = $("#pkL button[data-id]:not([data-id=''])", el) || $("#pkL button", el); if (b) b.click(); } };
    setTimeout(() => $("#pkQ", el).focus(), 30);
    const obs = new MutationObserver(() => { if (el.hidden) { obs.disconnect(); if (!picked) res(undefined); } });
    obs.observe(el, { attributes: true, attributeFilter: ["hidden"] });
  });
}

/* ================= Images ================= */
function loadImg(file) { return new Promise((res, rej) => { const u = URL.createObjectURL(file), i = new Image(); i.onload = () => res({ img: i, url: u }); i.onerror = () => { URL.revokeObjectURL(u); rej(new Error("img")); }; i.src = u; }); }
function cropper(host, img, onDone, onCancel, o = {}) {
  const size = o.size || 800, type = o.type || "image/jpeg";
  const W = img.naturalWidth, H = img.naturalHeight, base = Math.min(W, H);
  let z = 1, cx = W / 2, cy = H / 2;
  host.innerHTML = `<div class="cropper"><p class="help">Suratni suring va kattalashtiring. ${o.sq ? "Kvadrat" : "Doira"} ichidagi qism ${size}×${size} oʻlchamda saqlanadi.</p>
    <div class="crop-box${o.sq ? " sq" : ""}"><canvas width="560" height="560"></canvas></div>
    <div class="crop-ctl"><span>−</span><input type="range" min="1" max="4" step="0.01" value="1" aria-label="Kattalashtirish"><span>+</span></div>
    <div class="row"><button type="button" class="btn sm" data-c="x">Bekor qilish</button><button type="button" class="btn sm gold" data-c="ok">Shu holatda olish</button></div></div>`;
  const cv = $("canvas", host), ctx = cv.getContext("2d"), box = $(".crop-box", host), rng = $("input[type=range]", host);
  const clampC = () => { const s = base / z / 2; cx = Math.min(W - s, Math.max(s, cx)); cy = Math.min(H - s, Math.max(s, cy)); };
  const draw = () => { clampC(); const s = base / z; ctx.imageSmoothingQuality = "high"; ctx.clearRect(0, 0, 560, 560); ctx.drawImage(img, cx - s / 2, cy - s / 2, s, s, 0, 0, 560, 560); };
  draw();
  rng.oninput = e => { z = +e.target.value; draw(); };
  let drag = null;
  box.onpointerdown = e => { box.setPointerCapture(e.pointerId); drag = { x: e.clientX, y: e.clientY, cx, cy }; };
  box.onpointermove = e => { if (!drag) return; const k = (base / z) / box.clientWidth; cx = drag.cx - (e.clientX - drag.x) * k; cy = drag.cy - (e.clientY - drag.y) * k; draw(); };
  box.onpointerup = box.onpointercancel = () => drag = null;
  box.addEventListener("wheel", e => { e.preventDefault(); z = Math.min(4, Math.max(1, z * Math.exp(-e.deltaY * 0.002))); rng.value = z; draw(); }, { passive: false });
  $('[data-c="x"]', host).onclick = () => { host.innerHTML = ""; onCancel && onCancel(); };
  $('[data-c="ok"]', host).onclick = () => {
    const s = base / z, out = document.createElement("canvas"); out.width = out.height = size;
    const c2 = out.getContext("2d"); c2.imageSmoothingQuality = "high";
    if (type === "image/jpeg") { c2.fillStyle = "#fff"; c2.fillRect(0, 0, size, size); }
    c2.drawImage(img, cx - s / 2, cy - s / 2, s, s, 0, 0, size, size);
    out.toBlob(b => { host.innerHTML = ""; onDone(b, out.toDataURL(type, 0.85)); }, type, 0.92);
  };
}
async function resizeForBg(file) {
  const { img, url } = await loadImg(file); URL.revokeObjectURL(url);
  const k = Math.min(1, 2200 / img.naturalWidth), w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
  const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
  const c = cv.getContext("2d"); c.imageSmoothingQuality = "high"; c.drawImage(img, 0, 0, w, h);
  for (const q of [0.84, 0.74, 0.62, 0.5]) { const b = await new Promise(r => cv.toBlob(r, "image/jpeg", q)); if (b.size < 1350 * 1024) return b; }
  throw new Error("Rasm juda katta");
}

/* ================= Shell, nav, routing ================= */
const NAV = [
  ["", "home", "Bosh sahifa"], ["people", "people", "Insonlar"],
  ["-", "Sayt"], ["settings", "settings", "Sayt sozlamalari"], ["appearance", "palette", "Koʻrinish"], ["texts", "text", "Matnlar"], ["privacy", "lock", "Maxfiylik"],
  ["-", "Maʼlumot"], ["backup", "backup", "Zaxira va import"], ["security", "shield", "Xavfsizlik"], ["log", "history", "Oʻzgarishlar tarixi"]
];
let guard = null, curHash = "";
function renderShell() {
  $("#app").innerHTML = `<div class="shell" id="shell">
    <div class="topbar"><a class="brand" href="#/">${MARK}<span><b id="tbTitle"></b></span></a><button class="icon-btn" id="menuBtn" aria-label="Menyu">${I.menu}</button></div>
    <aside class="side" id="side">
      <a class="brand" href="#/">${MARK}<span><b id="sbTitle"></b><small>Boshqaruv paneli</small></span></a>
      <nav class="nav" id="nav"></nav>
      <div class="side-foot">
        <a href="/" target="_blank" rel="noopener">${I.ext}Saytni ochish</a>
        <a href="/?preview=visitor" target="_blank" rel="noopener">${I.eye}Mehmon koʻzi bilan</a>
        <button id="logout">${I.out}Chiqish</button>
      </div>
    </aside>
    <div class="scrim" id="scrim"></div>
    <main id="main"></main>
  </div>`;
  $("#menuBtn").onclick = () => $("#shell").classList.toggle("open");
  $("#scrim").onclick = () => $("#shell").classList.remove("open");
  $("#logout").onclick = async () => { if (guard && guard() && !confirm("Saqlanmagan oʻzgarishlar bor. Baribir chiqilsinmi?")) return; guard = null; await api("/api/logout", { method: "POST" }).catch(() => { }); showLogin(); };
  renderNav();
}
function renderNav() {
  const nav = $("#nav"); if (!nav) return;
  const cur = parseHash().path.split("/")[0];
  nav.innerHTML = NAV.map(n => n[0] === "-" ? `<div class="nav-g">${esc(n[1])}</div>` :
    `<a href="#/${n[0]}"${cur === n[0] ? ' aria-current="page"' : ""}>${I[n[1]]}<span>${esc(n[2])}</span>${n[0] === "people" ? `<span class="cnt">${A.people.size}</span>` : ""}</a>`).join("");
  const t = A.settings.title || A.settings.labels.defTitle || C.LABELS.defTitle;
  $("#sbTitle").textContent = t; $("#tbTitle").textContent = t;
}
function parseHash() { const h = location.hash.replace(/^#\/?/, ""); const i = h.indexOf("?"); return { path: i < 0 ? h : h.slice(0, i), q: new URLSearchParams(i < 0 ? "" : h.slice(i + 1)) }; }
const ROUTES = [
  [/^$/, () => pageHome()], [/^people$/, (m, q) => pagePeople(q)], [/^people\/new$/, (m, q) => pagePerson(null, q)], [/^people\/(.+)$/, (m, q) => pagePerson(decodeURIComponent(m[1]), q)],
  [/^settings$/, () => pageSettings()], [/^appearance$/, () => pageAppearance()], [/^texts$/, () => pageTexts()], [/^privacy$/, () => pagePrivacy()],
  [/^backup$/, () => pageBackup()], [/^security$/, () => pageSecurity()], [/^log$/, () => pageLog()]
];
function route() {
  guard = null; curHash = location.hash;
  const { path, q } = parseHash();
  $("#shell")?.classList.remove("open");
  renderNav();
  const main = $("#main"); main.innerHTML = ""; main.oninput = main.onchange = null;
  for (const [re, fn] of ROUTES) { const m = path.match(re); if (m) { fn(m, q); window.scrollTo(0, 0); return; } }
  main.innerHTML = `<div class="wrap"><div class="panel empty">Sahifa topilmadi. <a href="#/">Bosh sahifa</a></div></div>`;
}
window.addEventListener("hashchange", () => {
  if (!$("#main")) return;
  if (guard && guard() && !confirm("Saqlanmagan oʻzgarishlar bor. Ular yoʻqolsinmi?")) { history.replaceState(null, "", curHash || "#/"); return; }
  route();
});
window.addEventListener("beforeunload", e => { if (guard && guard()) { e.preventDefault(); e.returnValue = ""; } });
const header = (title, sub, acts = "", crumb = "") => `<div>${crumb ? `<div class="crumb">${crumb}</div>` : ""}<div class="ph"><div><h1>${esc(title)}</h1>${sub ? `<p>${sub}</p>` : ""}</div>${acts ? `<div class="acts">${acts}</div>` : ""}</div></div>`;

/* Floating save bar used by every editable page */
function saveBar(isDirty, onSave, onReset) {
  const bar = document.createElement("div"); bar.className = "savebar"; bar.hidden = true;
  bar.innerHTML = `<span>Saqlanmagan oʻzgarishlar bor</span><button class="btn sm" data-r>Bekor qilish</button><button class="btn sm primary" data-s>Saqlash</button>`;
  $("#main").appendChild(bar);
  const update = () => { bar.hidden = !isDirty(); };
  bar.querySelector("[data-r]").onclick = () => { onReset ? onReset() : (guard = null, route()); };
  bar.querySelector("[data-s]").onclick = async () => {
    const b = bar.querySelector("[data-s]"); b.disabled = true; b.textContent = "Saqlanmoqda…";
    try { await onSave(); } catch (e) { toast(e.message || "Saqlab boʻlmadi", true); }
    if (b.isConnected) { b.disabled = false; b.textContent = "Saqlash"; update(); }
  };
  guard = isDirty;
  return update;
}
async function saveSettings(draft, what) {
  const r = await api("/api/settings", { method: "PUT", json: { ...draft, _what: what } });
  A.settings = C.settingsOf(r.settings); renderNav();
  guard = null; toast("Saqlandi"); route();
}

/* ================= Login ================= */
async function showLogin(msg) {
  guard = null;
  let me = { configured: true }; try { me = await (await fetch("/api/me", { cache: "no-store" })).json(); } catch (e) { }
  $("#app").innerHTML = `<div class="login"><form id="lf" novalidate>
    <svg class="mark" aria-hidden="true"><use href="#treeMark"/></svg>
    <div><h1>Boshqaruv paneli</h1><p class="muted" style="margin:6px 0 0">Oila shajarasini tahrirlash va sozlash</p></div>
    ${msg ? `<p class="note warn">${esc(msg)}</p>` : ""}
    ${me.configured ? "" : `<p class="note bad">Serverda parol oʻrnatilmagan. Cloudflare → Worker → Settings → Variables and Secrets boʻlimida <b>ADMIN_PASSWORD</b> (Secret) qoʻshing va qayta deploy qiling.</p>`}
    <label class="f"><span>Parol</span><input id="lpw" type="password" autocomplete="current-password" required></label>
    <p class="err" id="lerr" hidden></p>
    <button class="btn primary" id="lgo" style="width:100%;padding:12px">Kirish</button>
    <a href="/" class="muted" style="font-size:14px">← Saytga qaytish</a></form></div>`;
  setTimeout(() => $("#lpw")?.focus(), 30);
  $("#lf").onsubmit = async e => {
    e.preventDefault(); const pw = $("#lpw").value; if (!pw) return;
    $("#lgo").disabled = true; $("#lgo").textContent = "Tekshirilmoqda…"; $("#lerr").hidden = true;
    try { await api("/api/login", { method: "POST", json: { password: pw } }); await start(); return; }
    catch (x) { $("#lerr").textContent = x.message; $("#lerr").hidden = false; }
    $("#lgo").disabled = false; $("#lgo").textContent = "Kirish";
  };
}
async function start() {
  try {
    const me = await (await fetch("/api/me", { cache: "no-store" })).json();
    if (!me.admin) return showLogin();
    await reload();
  } catch (e) {
    $("#app").innerHTML = `<div class="boot"><div class="panel" style="max-width:460px"><h2>Server bilan aloqa yoʻq</h2><p class="muted">${esc(e.message)}</p><button class="btn primary" onclick="location.reload()">Qayta urinish</button></div></div>`;
    return;
  }
  renderShell(); route();
}

/* ================= Page: Dashboard ================= */
function qualityChecks() {
  const all = [...A.people.values()], many = all.length > 1;
  const isolated = p => !P(p.fatherId) && !P(p.motherId) && !spousesOf(p).length && !kidsOf(p.id).length;
  const badOrder = p => { const y = year(p.birthDate); if (!y) return false; return [P(p.fatherId), P(p.motherId)].some(q => q && year(q.birthDate) && year(q.birthDate) > y - 12); };
  return [
    ["nodate", "Tugʻilgan yili kiritilmagan", "Yil boʻlmasa, yosh va avlod hisoblari chiqmaydi", all.filter(p => !year(p.birthDate)).length],
    ["nophoto", "Surati yoʻq", "Kartochkada faqat bosh harflar koʻrinadi", all.filter(p => !photoSrc(p)).length],
    ["isolated", "Hech kimga bogʻlanmagan", "Ota-ona, turmush oʻrtogʻi yoki farzand belgilanmagan", many ? all.filter(isolated).length : 0],
    ["old", "105 yoshdan katta, vafot belgisi yoʻq", "Ehtimol «Vafot etgan» belgisi qoʻyilmagan", all.filter(p => !isDead(p) && (ageOf(p) ?? 0) > 105).length],
    ["badorder", "Ota-ona yoshi mos kelmaydi", "Ota yoki ona farzanddan 12 yildan kam katta", all.filter(badOrder).length]
  ];
}
const ACT = { create: ["Qoʻshildi", "ok"], update: ["Tahrir", ""], delete: ["Oʻchirildi", "bad"], settings: ["Sozlama", "gold"], restore: ["Tiklash", "gold"], wipe: ["Tozalash", "bad"], photos: ["Suratlar", ""], security: ["Xavfsizlik", "gold"], login: ["Kirish", "ok"], login_fail: ["Xato kirish", "bad"] };
const actBadge = a => { const x = ACT[a] || [a, ""]; return `<span class="badge ${x[1]}">${esc(x[0])}</span>`; };
function feedRow(r) {
  const p = r.target && P(r.target);
  return `<div><time>${esc(fmtTime(r.at))}</time><span>${actBadge(r.action)} ${p ? `<a href="#/people/${encodeURIComponent(p.id)}">${esc(r.summary)}</a>` : esc(r.summary || "")}</span></div>`;
}
function pageHome() {
  const all = [...A.people.values()], living = all.filter(p => !isDead(p)).length;
  const s = A.settings, au = A.auth;
  const tiles = [["Jami insonlar", all.length, "#/people"], ["Hayot", living, "#/people?f=living"], ["Marhum", all.length - living, "#/people?f=dead"],
    ["Avlodlar", generations(), "#/people"], ["Surati bor", all.filter(p => photoSrc(p)).length, "#/people?f=photo"], ["Yashirin", all.filter(p => p.hidden).length, "#/people?f=hidden"]];
  const checks = qualityChecks();
  const status = [
    au.viewLocked ? `<span class="badge gold">${I.lock.replace("<svg", '<svg width="13" height="13"')} Sayt parol bilan yopiq</span>` : `<span class="badge">Sayt havolani bilganlarga ochiq</span>`,
    s.privacy.noindex ? `<span class="badge ok">Qidiruv tizimlaridan yashirin</span>` : `<span class="badge gold">Google’da koʻrinadi</span>`,
    au.ownPassword ? `<span class="badge ok">Admin paroli panelda oʻrnatilgan</span>` : `<span class="badge gold">Parol: ADMIN_PASSWORD (oʻzgartirish tavsiya etiladi)</span>`,
    au.backupToken ? `<span class="badge ok">Haftalik GitHub zaxirasi ulangan</span>` : `<span class="badge">Avtomatik zaxira sozlanmagan</span>`
  ].join("");
  $("#main").innerHTML = `<div class="wrap">
    ${header("Bosh sahifa", esc(s.title || C.LABELS.defTitle) + " — umumiy holat", `<a class="btn" href="/" target="_blank" rel="noopener">${I.ext}Saytni ochish</a><a class="btn gold" href="#/people/new">${I.plus}Yangi inson</a>`)}
    <div class="tiles">${tiles.map(([l, n, h]) => `<a class="tile" href="${h}"><b>${n}</b><span>${esc(l)}</span></a>`).join("")}</div>
    <div class="status">${status}</div>
    ${!all.length ? `<div class="panel"><h2>Shajarani boshlang</h2><p class="sub">Eng keksa maʼlum bobo yoki buvidan boshlang. Keyin har bir insonga ota-ona, turmush oʻrtogʻi va farzandlarini qoʻshib borasiz.</p><a class="btn primary" href="#/people/new">${I.plus}Birinchi insonni qoʻshish</a></div>` : ""}
    <div class="two">
      <section class="panel"><h2>Tekshirish kerak</h2><p class="sub">Maʼlumotlardagi boʻshliqlar va ehtimoliy xatolar</p>
        <div class="checks">${checks.map(([f, t, sub, n]) => `<a class="chk${n ? "" : " good"}" href="#/people?f=${f}"><span class="n">${n || "✓"}</span><span>${esc(t)}<small>${esc(sub)}</small></span>${I.chev.replace("<svg", '<svg width="16" height="16"')}</a>`).join("")}</div></section>
      <section class="panel"><h2>Soʻnggi oʻzgarishlar</h2><p class="sub"><a href="#/log">Toʻliq tarix →</a></p>
        <div class="feed">${A.recent.length ? A.recent.map(feedRow).join("") : `<p class="muted">Hali oʻzgarish yoʻq.</p>`}</div></section>
    </div>
    <section class="panel"><h2>Tezkor amallar</h2><p class="sub">Eng koʻp ishlatiladigan sozlamalar</p>
      <div class="row">
        <a class="btn" href="#/settings">${I.settings}Sayt nomi va boʻlimlar</a>
        <a class="btn" href="#/appearance">${I.palette}Ranglar va fon rasmi</a>
        <a class="btn" href="#/privacy">${I.lock}Kim koʻra oladi</a>
        <a class="btn" href="#/backup">${I.download}Zaxira yuklab olish</a>
      </div></section>
  </div>`;
}

/* ================= Page: People list ================= */
const PL = { q: "", f: "all", g: "all", sort: "name", dir: 1, sel: new Set() };
const FILTERS = [["all", "Hammasi"], ["living", "Hayot"], ["dead", "Marhum"], ["hidden", "Yashirin"], ["photo", "Surati bor"], ["nophoto", "Suratsiz"], ["nodate", "Yili yoʻq"], ["isolated", "Bogʻlanmagan"], ["old", "105+ yosh, tirik"], ["badorder", "Ota-ona yoshi mos emas"], ["noparents", "Ota-onasi kiritilmagan"]];
function filterFn(f) {
  const isolated = p => !P(p.fatherId) && !P(p.motherId) && !spousesOf(p).length && !kidsOf(p.id).length;
  return {
    all: () => true, living: p => !isDead(p), dead: isDead, hidden: p => p.hidden, photo: p => !!photoSrc(p), nophoto: p => !photoSrc(p),
    nodate: p => !year(p.birthDate), isolated, old: p => !isDead(p) && (ageOf(p) ?? 0) > 105, noparents: p => !P(p.fatherId) && !P(p.motherId),
    badorder: p => { const y = year(p.birthDate); return !!y && [P(p.fatherId), P(p.motherId)].some(q => q && year(q.birthDate) && year(q.birthDate) > y - 12); }
  }[f] || (() => true);
}
function pagePeople(q) {
  if (q.get("f")) PL.f = q.get("f");
  PL.sel = new Set([...PL.sel].filter(id => A.people.has(id)));
  $("#main").innerHTML = `<div class="wrap">
    ${header("Insonlar", `${A.people.size} kishi. Qatorni bosing — barcha maʼlumotlari tahrirlanadi.`, `<a class="btn gold" href="#/people/new">${I.plus}Yangi inson</a>`)}
    <div class="toolbar">
      <div class="search">${I.search}<input class="in" id="pq" placeholder="Ism, familiya yoki joy…" value="${esc(PL.q)}" autocomplete="off"></div>
      <select class="in" id="pf" style="width:auto">${FILTERS.map(([k, l]) => `<option value="${k}"${PL.f === k ? " selected" : ""}>${esc(l)}</option>`).join("")}</select>
      <div class="seg" id="pg">${[["all", "Hammasi"], ["m", "Erkaklar"], ["f", "Ayollar"]].map(([k, l]) => `<button data-g="${k}" aria-pressed="${PL.g === k}">${l}</button>`).join("")}</div>
    </div>
    <div class="bulk" id="bulk" hidden></div>
    <div class="panel flush"><div class="tbl-scroll"><table><thead id="pth"></thead><tbody id="ptb"></tbody></table></div><div id="pempty"></div></div>
  </div>`;
  const draw = () => {
    const qv = norm(PL.q.trim()), ff = filterFn(PL.f);
    let rows = [...A.people.values()].filter(p => ff(p) && (PL.g === "all" || (p.gender === "f" ? "f" : "m") === PL.g) &&
      (!qv || norm([full(p), p.birthPlace, p.occupation].join(" ")).includes(qv)));
    const key = { name: p => short(p).toLowerCase(), birth: bKey, kids: p => kidsOf(p.id).length, upd: p => -(p._updated || 0) }[PL.sort] || (p => short(p));
    rows.sort((a, b) => { const x = key(a), y = key(b); return (x < y ? -1 : x > y ? 1 : 0) * PL.dir; });
    const th = (k, l, cls = "") => `<th class="${cls}"><button data-sort="${k}"${PL.sort === k ? ` aria-sort="${PL.dir > 0 ? "ascending" : "descending"}"` : ""}>${l}</button></th>`;
    const allOn = rows.length && rows.every(p => PL.sel.has(p.id));
    $("#pth").innerHTML = `<tr><th class="ck"><input type="checkbox" id="ckAll" aria-label="Hammasini tanlash"${allOn ? " checked" : ""}></th>${th("name", "Inson")}${th("birth", "Yillar")}<th class="hide-m">Ota-onasi</th>${th("kids", "Farzand", "hide-m")}<th>Holati</th>${th("upd", "Oʻzgargan", "hide-m")}</tr>`;
    $("#ptb").innerHTML = rows.map(p => {
      const fa = P(p.fatherId), mo = P(p.motherId);
      return `<tr class="go${PL.sel.has(p.id) ? " on" : ""}" data-id="${esc(p.id)}">
        <td class="ck"><input type="checkbox" data-ck="${esc(p.id)}"${PL.sel.has(p.id) ? " checked" : ""} aria-label="Tanlash"></td>
        <td>${whoHtml(p, p.patronymic || (p.birthPlace || ""))}</td>
        <td>${esc(yrs(p))}</td>
        <td class="hide-m muted" style="font-size:13.5px">${[fa, mo].filter(Boolean).map(short).map(esc).join("<br>") || "—"}</td>
        <td class="hide-m">${kidsOf(p.id).length || ""}</td>
        <td><div class="row" style="gap:4px">${isDead(p) ? `<span class="badge">Marhum</span>` : ""}${p.hidden ? `<span class="badge dash">Yashirin</span>` : ""}${!year(p.birthDate) ? `<span class="badge gold">Yil yoʻq</span>` : ""}</div></td>
        <td class="hide-m muted" style="font-size:13px">${p._updated ? esc(fmtTime(p._updated).slice(0, 10)) : ""}</td></tr>`;
    }).join("");
    $("#pempty").innerHTML = rows.length ? "" : `<div class="empty">${A.people.size ? "Mos keladigan inson yoʻq." : `Hali hech kim qoʻshilmagan. <a href="#/people/new">Birinchi insonni qoʻshing</a>`}</div>`;
    $$("#ptb tr").forEach(tr => tr.onclick = e => { if (e.target.closest("td.ck")) return; location.hash = "#/people/" + encodeURIComponent(tr.dataset.id); });
    $$("[data-ck]").forEach(c => c.onchange = () => { c.checked ? PL.sel.add(c.dataset.ck) : PL.sel.delete(c.dataset.ck); c.closest("tr").classList.toggle("on", c.checked); drawBulk(); $("#ckAll").checked = rows.every(p => PL.sel.has(p.id)); });
    $("#ckAll").onchange = e => { rows.forEach(p => e.target.checked ? PL.sel.add(p.id) : PL.sel.delete(p.id)); draw(); };
    $$("[data-sort]").forEach(b => b.onclick = () => { const k = b.dataset.sort; PL.dir = PL.sort === k ? -PL.dir : 1; PL.sort = k; draw(); });
    drawBulk();
  };
  const drawBulk = () => {
    const n = PL.sel.size, b = $("#bulk"); b.hidden = !n; if (!n) return;
    b.innerHTML = `<b>${n} kishi tanlandi</b><button class="btn sm" data-b="hide">Yashirish</button><button class="btn sm" data-b="show">Koʻrsatish</button><button class="btn sm danger" data-b="delete">Oʻchirish</button><button class="btn sm" data-b="clear">Bekor</button>`;
    $$("[data-b]", b).forEach(x => x.onclick = async () => {
      const act = x.dataset.b;
      if (act === "clear") { PL.sel.clear(); draw(); return; }
      if (act === "delete" && !(await confirmDlg({ title: `${n} kishi oʻchirilsinmi?`, text: "Ularga bogʻlangan ota-ona, turmush oʻrtogʻi va farzandlik aloqalari ham uziladi. Bu amalni ortga qaytarib boʻlmaydi.", ok: "Ha, oʻchirilsin", danger: true }))) return;
      try { const r = await api("/api/people-bulk", { method: "POST", json: { ids: [...PL.sel], action: act } }); PL.sel.clear(); await reload(); toast(act === "delete" ? `${r.n} kishi oʻchirildi` : "Saqlandi"); draw(); }
      catch (e) { toast(e.message, true); }
    });
  };
  $("#pq").oninput = e => { PL.q = e.target.value; draw(); };
  $("#pf").onchange = e => { PL.f = e.target.value; history.replaceState(null, "", "#/people" + (PL.f !== "all" ? "?f=" + PL.f : "")); curHash = location.hash; draw(); };
  $$("#pg [data-g]").forEach(b => b.onclick = () => { PL.g = b.dataset.g; $$("#pg [data-g]").forEach(x => x.setAttribute("aria-pressed", x === b)); draw(); });
  draw();
  if (PL.q) $("#pq").focus();
}

/* ================= Page: Person editor ================= */
function dateField(id, label, val) {
  const o = parseDate(val) || {};
  return `<div class="f"><span>${esc(label)}</span><div class="date-in">
    <input id="${id}D" inputmode="numeric" placeholder="Kun" value="${o.d || ""}" maxlength="2" aria-label="${esc(label)}: kun">
    <select id="${id}M" aria-label="${esc(label)}: oy"><option value="">Oy</option>${MONTHS.map((m, i) => `<option value="${i + 1}"${o.m === i + 1 ? " selected" : ""}>${esc(capF(m))}</option>`).join("")}</select>
    <input id="${id}Y" inputmode="numeric" placeholder="Yil" value="${o.y || ""}" maxlength="4" aria-label="${esc(label)}: yil"></div></div>`;
}
function readDate(id) {
  const d = parseInt($("#" + id + "D").value, 10) || null, m = parseInt($("#" + id + "M").value, 10) || null, y = parseInt($("#" + id + "Y").value, 10) || null;
  if (y && (y < 1000 || y > new Date().getFullYear())) return { err: "Yil notoʻgʻri." };
  if (d && !m) return { err: "Kun kiritilgan, lekin oy tanlanmagan." };
  if (d && m) { const dim = new Date(y || 2000, m, 0).getDate(); if (d < 1 || d > dim) return { err: "Sana notoʻgʻri: bunday kun shu oyda yoʻq." }; }
  return { o: (m || y) ? { d: m ? d : null, m, y } : null };
}
function presetFor(q) {
  const rel = q.get("rel"), of = P(q.get("of"));
  if (!of) return {};
  if (rel === "father") return { gender: "m", lastName: of.lastName ? of.lastName.replace(/(ova|eva)$/i, m => m.slice(0, 2)) : "", spouses: of.motherId && P(of.motherId) ? [of.motherId] : [], after: { child: of.id, role: "fatherId" }, ctx: short(of) + "ning otasi", back: of.id };
  if (rel === "mother") return { gender: "f", spouses: of.fatherId && P(of.fatherId) ? [of.fatherId] : [], after: { child: of.id, role: "motherId" }, ctx: short(of) + "ning onasi", back: of.id };
  if (rel === "spouse") return { gender: of.gender === "f" ? "m" : "f", spouses: [of.id], ctx: short(of) + "ning turmush oʻrtogʻi", back: of.id };
  if (rel === "child") {
    const sps = (of.spouses || []).filter(P), other = sps.length === 1 ? sps[0] : null;
    const fa = of.gender === "f" ? P(other) : of;
    return { gender: "m", fatherId: fa?.id || null, motherId: of.gender === "f" ? of.id : other, lastName: fa?.lastName || "", ctx: short(of) + "ning farzandi", back: of.id };
  }
  return {};
}
function pagePerson(id, q) {
  const p = id ? P(id) : null;
  if (id && !p) { $("#main").innerHTML = `<div class="wrap">${header("Topilmadi", "Bunday inson yoʻq yoki oʻchirilgan.", "", `<a href="#/people">Insonlar</a>`)}</div>`; return; }
  const pre = p ? {} : presetFor(q);
  const d = p ? clone(p) : { firstName: "", lastName: pre.lastName || "", patronymic: "", gender: pre.gender || "m", birthDate: "", birthPlace: "", deathDate: "", deceased: false,
    burialPlace: "", occupation: "", bio: "", photo: null, photoId: null, fatherId: pre.fatherId || null, motherId: pre.motherId || null, spouses: pre.spouses ? [...pre.spouses] : [], hidden: false, privateNote: "" };
  d.spouses = (d.spouses || []).filter(P);
  if (!p && !d.patronymic) d.patronymic = patrOf(P(d.fatherId), d.gender);
  let autoPatr = patrOf(P(d.fatherId), d.gender), newBlob = null, newPreview = null;
  const nid = id || genId();
  const kids = p ? kidsOf(id) : [], sibs = p ? siblingsOf(p) : [];

  $("#main").innerHTML = `<div class="wrap">
    ${header(p ? full(p) : "Yangi inson", pre.ctx ? esc(pre.ctx) : p ? esc([yrs(p), ageOf(p) != null && !isDead(p) ? ageOf(p) + " yosh" : ""].filter(Boolean).join(" · ")) : "Barcha maydonlar ixtiyoriy, faqat ism shart.",
      p ? `<a class="btn" href="/?p=${encodeURIComponent(id)}" target="_blank" rel="noopener">${I.ext}Saytda koʻrish</a>` : "", `<a href="#/people">Insonlar</a> ›`)}
    <form class="cols" id="pf" novalidate>
      <div class="stack">
        <section class="panel"><h2>Asosiy maʼlumot</h2><p class="sub">Ism-sharif va jinsi</p>
          <div class="fields">
            <div class="g3">
              <label class="f"><span>Ism <em>*</em></span><input id="fFirst" value="${esc(d.firstName)}" autocomplete="off" required></label>
              <label class="f"><span>Familiya</span><input id="fLast" value="${esc(d.lastName)}" autocomplete="off"></label>
              <label class="f"><span>Otasining ismi</span><input id="fPatr" value="${esc(d.patronymic)}" autocomplete="off"></label>
            </div>
            <div class="f"><span>Jinsi</span><div class="seg" id="fG" style="justify-self:start"><button type="button" data-g="m" aria-pressed="${d.gender !== "f"}">Erkak</button><button type="button" data-g="f" aria-pressed="${d.gender === "f"}">Ayol</button></div></div>
          </div></section>

        <section class="panel"><h2>Hayot sanalari</h2><p class="sub">Faqat yilni bilsangiz, kun va oyni boʻsh qoldiring. Eslatmalar uchun kun va oy kerak.</p>
          <div class="fields">
            <div class="g2">${dateField("fB", "Tugʻilgan sana", d.birthDate)}<label class="f"><span>Tugʻilgan joyi</span><input id="fBp" value="${esc(d.birthPlace)}" placeholder="masalan: Samarqand"></label></div>
            <label class="check"><input type="checkbox" id="fDead"${isDead(d) ? " checked" : ""}> Vafot etgan</label>
            <div class="g2" id="deathF"${isDead(d) ? "" : " hidden"}>${dateField("fX", "Vafot etgan sana", d.deathDate)}<label class="f"><span>Dafn etilgan joyi</span><input id="fDp" value="${esc(d.burialPlace)}"></label></div>
          </div></section>

        <section class="panel"><h2>Kasbi va tarjimai hol</h2><p class="sub">Inson kartochkasidagi «Qisqacha maʼlumot» boʻlimi</p>
          <div class="fields">
            <label class="f"><span>Kasbi</span><input id="fJob" value="${esc(d.occupation || "")}" placeholder="masalan: oʻqituvchi, dehqon"></label>
            <label class="f"><span>Tarjimai hol</span><textarea id="fBio" placeholder="Hayot yoʻli, xizmatlari, oilaga qoldirgan xotiralari…">${esc(d.bio || "")}</textarea></label>
          </div></section>

        <section class="panel"><div class="sec-h"><div><h2>Oila</h2><p class="sub" style="margin:0">Ota-ona va turmush oʻrtogʻi shu yerda tanlanadi</p></div>
          ${p ? `<div class="row">${!P(p.fatherId) ? `<a class="btn sm" href="#/people/new?rel=father&of=${encodeURIComponent(id)}">${I.plus}Ota</a>` : ""}${!P(p.motherId) ? `<a class="btn sm" href="#/people/new?rel=mother&of=${encodeURIComponent(id)}">${I.plus}Ona</a>` : ""}<a class="btn sm" href="#/people/new?rel=spouse&of=${encodeURIComponent(id)}">${I.plus}Turmush oʻrtogʻi</a><a class="btn sm" href="#/people/new?rel=child&of=${encodeURIComponent(id)}">${I.plus}Farzand</a></div>` : ""}</div>
          <div class="fields" id="famBox"></div></section>

        <section class="panel"><h2>Admin uchun izoh</h2><p class="sub">Saytda koʻrinmaydi — faqat shu panelda</p>
          <label class="f"><textarea id="fNote" style="min-height:80px" placeholder="Telefon, manzil, manba, tekshirilishi kerak boʻlgan maʼlumot…">${esc(d.privateNote || "")}</textarea></label></section>
      </div>

      <aside>
        <section class="panel"><div class="photo-card"><span id="fAv"></span>
          <div class="row" style="justify-content:center"><label class="btn sm file-btn">${I.upload}Surat tanlash<input type="file" id="fPhoto" accept="image/jpeg,image/png,image/webp"></label><button type="button" class="btn sm" id="fPhotoDel">Olib tashlash</button></div>
          <p class="help">Kvadrat 800×800 · JPG, PNG yoki WEBP · kamida 400×400</p><div id="cropHost" style="width:100%"></div></div></section>
        <section class="panel"><h2 style="font-size:19px">Saytda koʻrinishi</h2>
          <label class="sw"><span class="t"><b>Saytda koʻrsatilsin</b><small>Oʻchirsangiz, bu inson mehmonlarga umuman koʻrinmaydi (siz koʻraverasiz).</small></span><input type="checkbox" id="fShow"${d.hidden ? "" : " checked"}></label>
          <p class="help" style="margin-top:8px">Tirik insonlar uchun qaysi maʼlumot yashirilishi <a href="#/privacy">Maxfiylik</a> boʻlimida belgilanadi.</p></section>
        ${p ? `<section class="panel"><h2 style="font-size:19px">Qoʻshimcha</h2>
          <p class="help">Qoʻshilgan: ${p.createdAt ? esc(fmtTime(p.createdAt)) : "—"}<br>Oxirgi oʻzgarish: ${p._updated ? esc(fmtTime(p._updated)) : "—"}<br>ID: <span class="mono">${esc(id)}</span></p></section>
        <section class="panel danger-zone"><h2 style="font-size:19px">Oʻchirish</h2><p class="sub">Bogʻlangan aloqalar avtomatik uziladi.</p><button type="button" class="btn danger" id="fDel">${I.trash}Bu insonni oʻchirish</button></section>` : ""}
      </aside>
    </form>
    <p class="err" id="fErr" hidden></p>
  </div>`;

  const v = s => $(s).value;
  const collect = () => ({ ...d, f: v("#fFirst"), l: v("#fLast"), pt: v("#fPatr"), bp: v("#fBp"), dp: v("#fDp"), j: v("#fJob"), b: v("#fBio"), n: v("#fNote"),
    bd: [v("#fBD"), v("#fBM"), v("#fBY")], xd: [v("#fXD"), v("#fXM"), v("#fXY")], dead: $("#fDead").checked, show: $("#fShow").checked, nb: !!newBlob });
  let orig = "";
  const drawAv = () => {
    const tmp = { ...d, firstName: v("#fFirst"), lastName: v("#fLast"), deceased: $("#fDead").checked };
    $("#fAv").innerHTML = avatar(tmp, newPreview || photoSrc(d)); $("#fPhotoDel").hidden = !(newPreview || d.photoId || d.photo);
  };
  const famRow = (q, rm) => `<div class="prow">${avatar(q)}<a href="#/people/${encodeURIComponent(q.id)}"><span class="who" style="gap:0"><span><b>${esc(short(q))}</b><small>${esc(yrs(q) || q.patronymic || " ")}</small></span></span></a>${rm ? `<button type="button" class="icon-btn" ${rm} aria-label="Olib tashlash" title="Olib tashlash">${I.x}</button>` : ""}</div>`;
  const pickBtn = (k, label, g) => { const q = P(d[k]);
    return `<div class="f"><span>${label}</span><div class="pick-wrap"><button type="button" class="pick" data-pick="${k}" data-g="${g}">${q ? whoHtml(q) : `<span class="ph0">Tanlash…</span>`}</button>${q ? `<button type="button" class="icon-btn" data-unpick="${k}" aria-label="Olib tashlash">${I.x}</button>` : ""}</div></div>`; };
  const drawFam = () => {
    const sp = d.spouses.map(P).filter(Boolean);
    $("#famBox").innerHTML = `<div class="g2">${pickBtn("fatherId", "Otasi", "m")}${pickBtn("motherId", "Onasi", "f")}</div>
      <div class="f"><span>Turmush oʻrtogʻi</span><div class="plist">${sp.map(q => famRow(q, `data-rmsp="${esc(q.id)}"`)).join("")}</div>
        <div><button type="button" class="btn sm" id="addSp">${I.plus}Mavjud insonni tanlash</button></div></div>
      ${p ? `<div class="f"><span>Farzandlari (${kids.length})</span><div class="plist">${kids.map(k => famRow(k, `data-unkid="${esc(k.id)}"`)).join("") || `<p class="help">Hali farzand kiritilmagan.</p>`}</div>
        <div class="row"><a class="btn sm" href="#/people/new?rel=child&of=${encodeURIComponent(id)}">${I.plus}Yangi farzand</a><button type="button" class="btn sm" id="addKid">${I.link}Mavjud insonni farzand qilish</button></div></div>
      ${sibs.length ? `<div class="f"><span>Aka-uka, opa-singillari (${sibs.length})</span><div class="plist">${sibs.map(s => famRow(s)).join("")}</div></div>` : ""}` : `<p class="help">Farzandlarni inson saqlangandan keyin qoʻshish mumkin.</p>`}`;
    $$("[data-pick]").forEach(b => b.onclick = async () => {
      const k = b.dataset.pick, ex = [nid, ...(p ? descendants(nid) : [])];
      const r = await openPicker({ title: k === "fatherId" ? "Otasini tanlang" : "Onasini tanlang", gender: b.dataset.g, exclude: ex, allowNone: true });
      if (r === undefined) return; d[k] = r; if (k === "fatherId") syncPatr(); drawFam(); upd();
    });
    $$("[data-unpick]").forEach(b => b.onclick = () => { d[b.dataset.unpick] = null; if (b.dataset.unpick === "fatherId") syncPatr(); drawFam(); upd(); });
    $$("[data-rmsp]").forEach(b => b.onclick = () => { d.spouses = d.spouses.filter(x => x !== b.dataset.rmsp); drawFam(); upd(); });
    $("#addSp").onclick = async () => {
      const r = await openPicker({ title: "Turmush oʻrtogʻini tanlang", gender: d.gender === "f" ? "m" : "f", exclude: [nid, ...d.spouses] });
      if (r) { d.spouses.push(r); drawFam(); upd(); }
    };
    if ($("#addKid")) $("#addKid").onclick = async () => {
      const anc = new Set(); (function up(x) { const q = P(x); if (!q) return; for (const y of [q.fatherId, q.motherId]) if (y && !anc.has(y)) { anc.add(y); up(y); } })(nid);
      const r = await openPicker({ title: "Farzandni tanlang", exclude: [nid, ...kids.map(k => k.id), ...anc], hint: `Tanlangan inson ${short(p)}ning farzandi sifatida belgilanadi.` });
      if (!r) return;
      try { await api("/api/people/" + encodeURIComponent(r), { method: "PATCH", json: { [p.gender === "f" ? "motherId" : "fatherId"]: id } }); await reload(); kids.splice(0, kids.length, ...kidsOf(id)); drawFam(); toast("Farzand biriktirildi"); }
      catch (e) { toast(e.message, true); }
    };
    $$("[data-unkid]").forEach(b => b.onclick = async () => {
      const k = P(b.dataset.unkid); if (!k) return;
      if (!(await confirmDlg({ title: "Farzandlikdan olib tashlansinmi?", text: `${short(k)} endi ${short(p)}ning farzandi sifatida koʻrsatilmaydi. Insonning oʻzi oʻchirilmaydi.`, ok: "Olib tashlash" }))) return;
      try { await api("/api/people/" + encodeURIComponent(k.id), { method: "PATCH", json: { [k.fatherId === id ? "fatherId" : "motherId"]: null } }); await reload(); kids.splice(0, kids.length, ...kidsOf(id)); drawFam(); toast("Olib tashlandi"); }
      catch (e) { toast(e.message, true); }
    });
  };
  const syncPatr = () => { const nv = patrOf(P(d.fatherId), d.gender), cur = v("#fPatr").trim(); if (!cur || cur === autoPatr) $("#fPatr").value = nv; autoPatr = nv; };
  drawAv(); drawFam();
  const upd = saveBar(() => JSON.stringify(collect()) !== orig, save);
  orig = JSON.stringify(collect());
  $("#pf").addEventListener("input", () => { upd(); }); $("#pf").addEventListener("change", upd);
  $("#fFirst").addEventListener("input", drawAv); $("#fLast").addEventListener("input", drawAv);
  $("#fDead").onchange = () => { $("#deathF").hidden = !$("#fDead").checked; drawAv(); upd(); };
  $$("#fG [data-g]").forEach(b => b.onclick = () => {
    d.gender = b.dataset.g; $$("#fG [data-g]").forEach(x => x.setAttribute("aria-pressed", x === b));
    const want = d.gender === "f" ? "m" : "f"; d.spouses = d.spouses.filter(x => P(x)?.gender === want);
    syncPatr(); drawAv(); drawFam(); upd();
  });
  $("#fPhoto").onchange = async e => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return; err(null);
    let li; try { li = await loadImg(f); } catch (x) { err("Suratni oʻqib boʻlmadi. JPG, PNG yoki WEBP tanlang."); return; }
    const { img, url } = li;
    if (Math.min(img.naturalWidth, img.naturalHeight) < 400) { URL.revokeObjectURL(url); err(`Surat juda kichik (${img.naturalWidth}×${img.naturalHeight}). Kamida 400×400 piksel boʻlsin.`); return; }
    cropper($("#cropHost"), img, (blob, dataUrl) => { URL.revokeObjectURL(url); newBlob = blob; newPreview = dataUrl; drawAv(); upd(); }, () => URL.revokeObjectURL(url));
  };
  $("#fPhotoDel").onclick = () => { newBlob = null; newPreview = null; d.photo = null; d.photoId = null; drawAv(); upd(); };
  if ($("#fDel")) $("#fDel").onclick = async () => {
    const links = kids.length + spousesOf(p).length + (P(p.fatherId) ? 1 : 0) + (P(p.motherId) ? 1 : 0);
    if (!(await confirmDlg({ title: `${short(p)} oʻchirilsinmi?`, text: `${links ? links + " ta oilaviy aloqa uziladi. " : ""}Surati ham oʻchiriladi. Bu amalni ortga qaytarib boʻlmaydi.`, ok: "Ha, oʻchirilsin", danger: true }))) return;
    try { await api("/api/people/" + encodeURIComponent(id), { method: "DELETE" }); guard = null; await reload(); toast("Oʻchirildi"); location.hash = "#/people"; }
    catch (e) { toast(e.message, true); }
  };
  function err(msg) { $("#fErr").textContent = msg || ""; $("#fErr").hidden = !msg; if (msg) toast(msg, true); }
  async function save() {
    err(null);
    const fn = v("#fFirst").trim();
    if (!fn) { err("Ismni kiriting."); $("#fFirst").focus(); return; }
    const dead = $("#fDead").checked;
    const bd = readDate("fB"), dd = dead ? readDate("fX") : { o: null };
    if (bd.err) { err("Tugʻilgan sana: " + bd.err); $("#fBD").focus(); return; }
    if (dd.err) { err("Vafot sanasi: " + dd.err); $("#fXD").focus(); return; }
    if (bd.o?.y && dd.o?.y) { const a = bd.o.y * 1e4 + (bd.o.m || 0) * 100 + (bd.o.d || 0), b = dd.o.y * 1e4 + (dd.o.m || 12) * 100 + (dd.o.d || 31); if (b < a) { err("Vafot sanasi tugʻilgan sanadan oldin boʻlishi mumkin emas."); return; } }
    let photoId = d.photoId || null, photo = d.photo || null;
    if (newBlob) { const up = await uploadPhoto(newBlob, "image/jpeg"); photoId = up.id; photo = null; }
    const data = { firstName: fn, lastName: v("#fLast").trim(), patronymic: v("#fPatr").trim(), gender: d.gender,
      birthDate: serDate(bd.o), birthPlace: v("#fBp").trim(), deathDate: dead ? serDate(dd.o) : "", deceased: dead, burialPlace: dead ? v("#fDp").trim() : "",
      occupation: v("#fJob").trim(), bio: v("#fBio").trim(), photo, photoId, fatherId: d.fatherId || null, motherId: d.motherId || null,
      spouses: [...new Set(d.spouses)], hidden: !$("#fShow").checked, privateNote: v("#fNote").trim(), createdAt: p?.createdAt || Date.now() };
    await api("/api/people/" + encodeURIComponent(nid), { method: "PUT", json: data });
    if (pre.after && P(pre.after.child)) await api("/api/people/" + encodeURIComponent(pre.after.child), { method: "PATCH", json: { [pre.after.role]: nid } });
    guard = null; await reload(); toast(p ? "Saqlandi" : `${short(data)} qoʻshildi`);
    if (pre.back && P(pre.back)) location.hash = "#/people/" + encodeURIComponent(pre.back);
    else if (!p) location.hash = "#/people/" + encodeURIComponent(nid);
    else route();
  }
  if (!p) setTimeout(() => $("#fFirst").focus(), 30);
}

/* ================= Page: Site settings ================= */
const FEATURES = [
  ["fan", "Doira koʻrinishi", "Ajdodlarni doira shaklida koʻrsatadigan boʻlim"],
  ["list", "Oila aʼzolari roʻyxati", "Jadval, statistika va yaqin sanalar sahifasi"],
  ["search", "Qidiruv", "Yuqoridagi ism boʻyicha qidiruv maydoni"],
  ["relations", "«Siz uchun» qarindoshlik", "Mehmon oʻzini belgilaydi va har kim unga kimligi (amaki, xola…) yoziladi"],
  ["yetti", "«Yetti ota» bloki", "Inson kartochkasida ota tomondan nechta boʻgʻin maʼlumligi"],
  ["upcoming", "Yaqin sanalar", "Tugʻilgan va xotira kunlari roʻyxati, «Bugungi sanalar» tugmasi"],
  ["stats", "Statistika", "Avlodlar soni kartochkasi va raqamlar"],
  ["script", "Lotin / Kirill tugmasi", "Mehmon yozuvni oʻzi almashtira oladi"],
  ["legend", "Doira izohi", "Doira koʻrinishidagi ranglar izohi"],
  ["export", "Eksport tugmasi", "Pastdagi uchta bandning umumiy kaliti"],
  ["poster", "— Plakat (SVG)", "Bosmaxona uchun katta plakat yasash"],
  ["calendar", "— Kalendar", "Tugʻilgan kunlarni Google / Apple kalendariga olish"],
  ["backup", "— Zaxira (JSON) mehmonlar uchun", "Mehmon saytning ochiq qismini fayl qilib yuklab oladi"],
  ["adminLink", "«Kirish» havolasi", "Saytning yon panelida admin panelga olib boruvchi kichik havola"]
];
const segHtml = (name, val, opts) => `<div class="seg" data-seg="${name}">${opts.map(([k, l]) => `<button type="button" data-v="${k}" aria-pressed="${val === k}">${esc(l)}</button>`).join("")}</div>`;
function bindSegs(root, draft, upd, onChange) {
  $$("[data-seg]", root).forEach(sg => $$("button", sg).forEach(b => b.onclick = () => {
    const path = sg.dataset.seg.split("."); let o = draft; for (let i = 0; i < path.length - 1; i++) o = o[path[i]];
    o[path[path.length - 1]] = b.dataset.v; $$("button", sg).forEach(x => x.setAttribute("aria-pressed", x === b)); upd(); onChange && onChange(sg.dataset.seg);
  }));
}
function pageSettings() {
  const s = clone(A.settings), orig = JSON.stringify(s);
  const personBtn = (k, ph) => { const q = P(s[k]); return `<div class="pick-wrap"><button type="button" class="pick" data-pk="${k}">${q ? whoHtml(q) : `<span class="ph0">${esc(ph)}</span>`}</button>${q ? `<button type="button" class="icon-btn" data-unpk="${k}" aria-label="Olib tashlash">${I.x}</button>` : ""}</div>`; };
  const draw = () => {
    $("#main").innerHTML = `<div class="wrap">
      ${header("Sayt sozlamalari", "Sayt nomi, ochilish holati va qaysi boʻlimlar koʻrinishi")}
      <div class="two">
        <div class="stack">
          <section class="panel"><h2>Asosiy</h2><p class="sub">Sarlavha va tavsiflar</p><div class="fields">
            <label class="f"><span>Sayt nomi</span><input data-s="title" value="${esc(s.title)}" placeholder="${esc(s.labels.defTitle || C.LABELS.defTitle)}"><small class="help">Yon panelda, brauzer oynasida va plakatda chiqadi.</small></label>
            <label class="f"><span>Qisqa shior</span><input data-s="subtitle" value="${esc(s.subtitle)}" placeholder="masalan: Qashqadaryo, Qarshi tumani"><small class="help">Sarlavha ostida kichik matn. Boʻsh qoldirsa ham boʻladi.</small></label>
            <label class="f"><span>Havola tavsifi</span><input data-s="description" value="${esc(s.description)}"><small class="help">Telegram va boshqa joylarda havola ulashilganda koʻrinadi.</small></label>
            <label class="f"><span>Plakat epigrafi</span><input data-s="epigraph" value="${esc(s.epigraph)}" placeholder="${esc(s.labels.epiDefault || C.LABELS.epiDefault)}"></label>
          </div></section>
          <section class="panel"><h2>Sayt ochilganda</h2><p class="sub">Mehmon birinchi marta kirganda koʻradigan holat</p><div class="fields">
            <div class="f"><span>Boshlangʻich koʻrinish</span>${segHtml("defaultView", s.defaultView, [["tree", "Daraxt"], ["fan", "Doira"], ["list", "Roʻyxat"]])}</div>
            <div class="f"><span>Yozuv</span>${segHtml("defaultScript", s.defaultScript, [["lat", "Lotin"], ["cyr", "Кирилл"]])}</div>
            <div class="f"><span>Katta daraxtni shoxlarga boʻlish</span>${segHtml("paged", s.paged, [["auto", "Avtomatik"], ["on", "Doim"], ["off", "Hech qachon"]])}<small class="help">Avtomatik — telefonda shoxlarga boʻlinadi, kompyuterda butun daraxt.</small></div>
            <div class="f"><span>Avlod boshi (daraxt kimdan boshlanadi)</span>${personBtn("rootId", "Avtomatik — eng katta avlodli ajdod")}</div>
            <div class="f"><span>Siz kimsiz (faqat admin uchun)</span>${personBtn("meId", "Belgilanmagan")}<small class="help">Saytni admin sifatida ochganingizda qarindoshlik shu insonga nisbatan yoziladi.</small></div>
            <label class="f"><span>«Yaqin sanalar» oraligʻi (kun)</span><input type="number" min="1" max="365" data-s="upcomingDays" value="${s.upcomingDays}" style="max-width:140px"></label>
          </div></section>
          <section class="panel"><h2>Plakat standartlari</h2><p class="sub">Eksport oynasida oldindan tanlangan qiymatlar</p><div class="fields">
            <div class="f"><span>Qogʻoz oʻlchami</span>${segHtml("poster.paper", s.poster.paper, [["A3", "A3"], ["A2", "A2"], ["A1", "A1"], ["A0", "A0"], ["auto", "Asl"]])}</div>
            <div class="f"><span>Rangi</span>${segHtml("poster.theme", s.poster.theme, [["dark", "Lojuvard"], ["light", "Oq qogʻoz"]])}</div>
            <label class="check"><input type="checkbox" data-b="poster.photos"${s.poster.photos ? " checked" : ""}> Suratlar bilan</label>
          </div></section>
        </div>
        <section class="panel"><h2>Boʻlimlar va tugmalar</h2><p class="sub">Oʻchirilgan boʻlim saytda umuman koʻrinmaydi</p>
          ${FEATURES.map(([k, t, sub]) => `<label class="sw"><span class="t"><b>${esc(t)}</b><small>${esc(sub)}</small></span><input type="checkbox" data-b="features.${k}"${s.features[k] ? " checked" : ""}></label>`).join("")}
        </section>
      </div></div>`;
    $$("[data-s]").forEach(el => el.oninput = () => { s[el.dataset.s] = el.type === "number" ? (+el.value || 30) : el.value; upd(); });
    $$("[data-b]").forEach(el => el.onchange = () => { const [a, b] = el.dataset.b.split("."); s[a][b] = el.checked; upd(); });
    bindSegs($("#main"), s, () => upd());
    $$("[data-pk]").forEach(b => b.onclick = async () => {
      const k = b.dataset.pk, r = await openPicker({ title: k === "rootId" ? "Avlod boshini tanlang" : "Siz kimsiz?", allowNone: true });
      if (r === undefined) return; s[k] = r; redraw();
    });
    $$("[data-unpk]").forEach(b => b.onclick = () => { s[b.dataset.unpk] = null; redraw(); });
    upd = saveBar(() => JSON.stringify(s) !== orig, () => saveSettings(s, "Sayt sozlamalari saqlandi"));
    upd();
  };
  let upd = () => { };
  const redraw = () => { const y = window.scrollY; draw(); window.scrollTo(0, y); };
  draw();
}

/* ================= Page: Appearance ================= */
const PRESETS = [
  ["Samarqand (standart)", {}],
  ["Lojuvard", { green: "#24467A", gold: "#B08433", man: "#4F78B0", woman: "#B86A7F", branch: "#9C8455" }],
  ["Anor", { green: "#7A2E3A", gold: "#A8742C", man: "#56789E", woman: "#C25E6E", branch: "#A9824A" }],
  ["Zaytun", { green: "#4E5F2E", gold: "#9A7A2E", man: "#5E7FA0", woman: "#B97A6F", branch: "#8F8046" }],
  ["Firuza", { green: "#1D6A6A", gold: "#B0822E", man: "#3F7FA8", woman: "#C0707E", branch: "#A88B55" }]
];
function pageAppearance() {
  const s = clone(A.settings), orig = JSON.stringify(s);
  let tab = "light", upd = () => { };
  const def = (k, t) => { const c = C.COLORS.find(x => x[0] === k); return t === "dark" ? c[3] : c[2]; };
  const val = (k, t) => s.theme[t][k] || def(k, t);
  const pvVars = () => C.COLORS.map(([k]) => `--p-${k}:${val(k, tab)}`).join(";");
  const bgUrl = () => s.scene.photoId ? "/_blob/" + s.scene.photoId : "/img/tree.jpg";
  const draw = () => {
    $("#main").innerHTML = `<div class="wrap">
      ${header("Koʻrinish", "Ranglar, fon rasmi va logotip. Oʻzgarish saqlangach saytda darhol koʻrinadi.")}
      <div class="cols">
        <div class="stack">
          <section class="panel"><h2>Rang rejimi</h2><p class="sub">Yorugʻ yoki qorongʻi mavzu</p>
            ${segHtml("theme.mode", s.theme.mode, [["auto", "Qurilmaga qarab"], ["light", "Doim yorugʻ"], ["dark", "Doim qorongʻi"]])}</section>
          <section class="panel"><div class="sec-h"><div><h2>Ranglar</h2><p class="sub" style="margin:0">Har bir rejim uchun alohida</p></div>
            <div class="seg" id="tabs"><button type="button" data-t="light" aria-pressed="${tab === "light"}">Yorugʻ</button><button type="button" data-t="dark" aria-pressed="${tab === "dark"}">Qorongʻi</button></div></div>
            ${tab === "light" ? `<div class="f" style="margin-bottom:12px"><span>Tayyor palitralar</span><div class="presets">${PRESETS.map(([n, c], i) => `<button type="button" class="preset" data-pre="${i}"><i>${["green", "gold", "man", "woman"].map(k => `<b style="background:${c[k] || def(k, "light")}"></b>`).join("")}</i>${esc(n)}</button>`).join("")}</div></div>` : ""}
            <div class="colors">${C.COLORS.map(([k, n]) => { const cur = val(k, tab), changed = !!s.theme[tab][k];
              return `<div class="crow"><input type="color" data-c="${k}" value="${cur.toLowerCase()}" aria-label="${esc(n)}"><span class="nm">${esc(n)}${changed ? `<small>oʻzgartirilgan · standart ${def(k, tab)}</small>` : `<small>standart</small>`}</span><input class="in" data-hex="${k}" value="${cur.toUpperCase()}" maxlength="7" spellcheck="false"><button type="button" class="icon-btn" data-rc="${k}" title="Standartga qaytarish" aria-label="Standartga qaytarish"${changed ? "" : " hidden"}>${I.reset}</button></div>`; }).join("")}</div>
            <div class="row" style="margin-top:12px"><button type="button" class="btn sm" id="rcAll">${I.reset}${tab === "light" ? "Yorugʻ" : "Qorongʻi"} ranglarni tiklash</button></div></section>
          <section class="panel"><h2>Fon rasmi</h2><p class="sub">Daraxt ortidagi manzara. Kengligi 1600 px dan katta, gorizontal rasm tavsiya etiladi.</p>
            <div class="fields"><div class="img-prev" style="background-image:url('${esc(bgUrl())}');background-position:center ${s.scene.position}"></div>
              <div class="row"><label class="btn sm file-btn">${I.upload}Boshqa rasm yuklash<input type="file" id="bgFile" accept="image/jpeg,image/png,image/webp"></label>${s.scene.photoId ? `<button type="button" class="btn sm" id="bgReset">${I.reset}Standart rasmga qaytarish</button>` : ""}<span class="help" id="bgMsg"></span></div>
              <div class="f"><span>Rasmning qaysi qismi koʻrinsin</span>${segHtml("scene.position", s.scene.position, [["10%", "Yuqori"], ["35%", "Yuqoriroq"], ["62%", "Oʻrta"], ["90%", "Past"]])}</div>
              <label class="sw"><span class="t"><b>Fon rasmini koʻrsatish</b><small>Oʻchirilsa, faqat bir tekis rang qoladi</small></span><input type="checkbox" id="bgShow"${s.scene.show ? " checked" : ""}></label></div></section>
          <section class="panel"><h2>Logotip</h2><p class="sub">Sarlavha yonidagi belgi. Standart — daraxt belgisi.</p>
            <div class="row" style="gap:16px"><div class="logo-prev">${s.logoPhotoId ? `<img src="/_blob/${esc(s.logoPhotoId)}" alt="">` : MARK}</div>
              <div class="row"><label class="btn sm file-btn">${I.upload}Logotip yuklash<input type="file" id="lgFile" accept="image/jpeg,image/png,image/webp"></label>${s.logoPhotoId ? `<button type="button" class="btn sm" id="lgReset">${I.reset}Standart belgi</button>` : ""}</div></div>
            <div id="lgCrop" style="margin-top:12px"></div></section>
        </div>
        <aside><section class="panel"><h2 style="font-size:19px">Namuna</h2><p class="sub">${tab === "light" ? "Yorugʻ" : "Qorongʻi"} rejimda shunday koʻrinadi</p>
          <div class="pv"><div class="pv-in" style="${pvVars()}">
            <div class="pv-top">${MARK}<b>${esc(s.title || C.LABELS.defTitle)}</b></div>
            <div class="pv-cards"><div class="pv-card"><em>Bobo</em><i>AK</i><b>Abdulla</b><span>1930 – 1999</span></div><div class="pv-card f"><em>Buvi</em><i>SK</i><b>Saodat</b><span>1935 – 2010</span></div></div>
            <div class="pv-line"></div>
            <div class="pv-btns"><span class="a">Shajara daraxti</span><span class="b">Bu — men</span></div>
          </div></div></section></aside>
      </div></div>`;
    bindSegs($("#main"), s, () => upd(), seg => { if (seg === "scene.position") redraw(); });
    $$("#tabs [data-t]").forEach(b => b.onclick = () => { tab = b.dataset.t; redraw(); });
    $$("[data-pre]").forEach(b => b.onclick = () => { s.theme.light = { ...PRESETS[+b.dataset.pre][1] }; redraw(); });
    const setC = (k, v) => { v = v.toUpperCase(); if (v === def(k, tab).toUpperCase()) delete s.theme[tab][k]; else s.theme[tab][k] = v; };
    $$("[data-c]").forEach(el => { el.oninput = () => { setC(el.dataset.c, el.value); $(`[data-hex="${el.dataset.c}"]`).value = el.value.toUpperCase(); $(".pv-in").setAttribute("style", pvVars()); upd(); }; el.onchange = redraw; });
    $$("[data-hex]").forEach(el => el.oninput = () => { const v = el.value.trim(); if (/^#[0-9a-fA-F]{6}$/.test(v)) { setC(el.dataset.hex, v); $(`[data-c="${el.dataset.hex}"]`).value = v.toLowerCase(); $(".pv-in").setAttribute("style", pvVars()); upd(); } });
    $$("[data-hex]").forEach(el => el.onchange = redraw);
    $$("[data-rc]").forEach(b => b.onclick = () => { delete s.theme[tab][b.dataset.rc]; redraw(); });
    $("#rcAll").onclick = () => { s.theme[tab] = {}; redraw(); };
    $("#bgShow").onchange = e => { s.scene.show = e.target.checked; upd(); };
    $("#bgFile").onchange = async e => {
      const f = e.target.files[0]; e.target.value = ""; if (!f) return;
      $("#bgMsg").textContent = "Yuklanmoqda…";
      try { const blob = await resizeForBg(f); const up = await uploadPhoto(blob, "image/jpeg"); s.scene.photoId = up.id; s.scene.show = true; redraw(); toast("Rasm yuklandi — saqlashni unutmang"); }
      catch (x) { $("#bgMsg").textContent = ""; toast(x.message || "Rasmni yuklab boʻlmadi", true); }
    };
    if ($("#bgReset")) $("#bgReset").onclick = () => { s.scene.photoId = null; redraw(); };
    $("#lgFile").onchange = async e => {
      const f = e.target.files[0]; e.target.value = ""; if (!f) return;
      let li; try { li = await loadImg(f); } catch (x) { toast("Rasmni oʻqib boʻlmadi", true); return; }
      cropper($("#lgCrop"), li.img, async blob => { URL.revokeObjectURL(li.url);
        try { const up = await uploadPhoto(blob, "image/png"); s.logoPhotoId = up.id; redraw(); toast("Logotip yuklandi — saqlashni unutmang"); } catch (x) { toast(x.message, true); }
      }, () => URL.revokeObjectURL(li.url), { size: 256, type: "image/png", sq: true });
    };
    if ($("#lgReset")) $("#lgReset").onclick = () => { s.logoPhotoId = null; redraw(); };
    upd = saveBar(() => JSON.stringify(s) !== orig, () => saveSettings(s, "Koʻrinish sozlamalari saqlandi"));
    upd();
  };
  const redraw = () => { const y = window.scrollY; draw(); window.scrollTo(0, y); };
  draw();
}

/* ================= Page: Texts ================= */
function pageTexts() {
  const s = clone(A.settings), orig = JSON.stringify(s.labels);
  let q = "", onlyChanged = false, upd = () => { };
  $("#main").innerHTML = `<div class="wrap">
    ${header("Matnlar", "Saytdagi har bir yozuvni oʻzgartirish mumkin. Boʻsh qoldirilsa — standart matn ishlatiladi.")}
    <p class="note">Jingalak qavs ichidagi <b>{n}</b>, <b>{w}</b> kabi belgilar oʻrniga son qoʻyiladi — ularni oʻchirmang. Kirill yozuviga sayt oʻzi oʻgiradi.</p>
    <div class="toolbar"><div class="search">${I.search}<input class="in" id="tq" placeholder="Matn yoki kalit boʻyicha qidirish…" autocomplete="off"></div>
      <label class="check"><input type="checkbox" id="tch"> Faqat oʻzgartirilganlar <span class="badge gold" id="tcnt"></span></label></div>
    <div class="stack" id="tg"></div></div>`;
  const draw = () => {
    const qq = norm(q);
    const groups = C.LABEL_GROUPS.map(([g, keys]) => [g, keys.filter(k => (!onlyChanged || s.labels[k] !== undefined) && (!qq || norm(k + " " + C.LABELS[k] + " " + (s.labels[k] || "")).includes(qq)))]).filter(x => x[1].length);
    $("#tg").innerHTML = groups.length ? groups.map(([g, keys]) => `<section class="panel"><h2>${esc(g)}</h2><p class="sub">${keys.length} ta matn</p>
      ${keys.map(k => { const dv = C.LABELS[k], cur = s.labels[k] ?? "", long = dv.length > 70;
        return `<div class="trow${cur ? " changed" : ""}" data-row="${k}"><div class="def">${esc(dv)}<small class="mono">${k}${C.HTML_LABELS.includes(k) ? " · HTML ruxsat" : ""}</small></div>
          <textarea data-k="${k}" rows="${long ? 3 : 1}" placeholder="${esc(dv)}">${esc(cur)}</textarea>
          <button type="button" class="icon-btn" data-rk="${k}" title="Standartga qaytarish" aria-label="Standartga qaytarish"${cur ? "" : " hidden"}>${I.reset}</button></div>`; }).join("")}</section>`).join("")
      : `<div class="panel empty">Hech narsa topilmadi.</div>`;
    $$("[data-k]").forEach(el => el.oninput = () => {
      const k = el.dataset.k, v = el.value;
      if (!v.trim() || v === C.LABELS[k]) delete s.labels[k]; else s.labels[k] = v;
      el.closest(".trow").classList.toggle("changed", s.labels[k] !== undefined); $(`[data-rk="${k}"]`).hidden = s.labels[k] === undefined; count(); upd();
    });
    $$("[data-rk]").forEach(b => b.onclick = () => { delete s.labels[b.dataset.rk]; const ta = $(`[data-k="${b.dataset.rk}"]`); ta.value = ""; ta.closest(".trow").classList.remove("changed"); b.hidden = true; count(); upd(); });
  };
  const count = () => { const n = Object.keys(s.labels).length; $("#tcnt").textContent = n; $("#tcnt").hidden = !n; };
  $("#tq").oninput = e => { q = e.target.value; draw(); };
  $("#tch").onchange = e => { onlyChanged = e.target.checked; draw(); };
  draw(); count();
  upd = saveBar(() => JSON.stringify(s.labels) !== orig, () => saveSettings(s, "Matnlar saqlandi"));
}

/* ================= Page: Privacy ================= */
function pagePrivacy() {
  const s = clone(A.settings), orig = JSON.stringify(s.privacy) + s.features.backup;
  const locked = A.auth.viewLocked, hidden = [...A.people.values()].filter(p => p.hidden).length;
  const PRIV = [["birthDay", "Tugʻilgan kun va oy", "Faqat yili koʻrinadi (masalan, 1990)"], ["birthPlace", "Tugʻilgan joyi", ""], ["photo", "Surati", "Kartochkada bosh harflar koʻrinadi"], ["occupation", "Kasbi", ""], ["bio", "Tarjimai holi", ""]];
  $("#main").innerHTML = `<div class="wrap">
    ${header("Maxfiylik", "Saytni kim koʻra oladi va mehmonlarga qaysi maʼlumot koʻrsatiladi")}
    <section class="panel"><h2>Saytga kirish</h2>
      ${locked ? `<p class="note good" style="margin:8px 0 16px"><b>Sayt yopiq.</b> Faqat ko‘rish parolini bilgan qarindoshlar ko‘ra oladi. Parolni bir marta kiritgan qurilma 1 yil eslab qoladi.</p>`
        : `<p class="note warn" style="margin:8px 0 16px"><b>Sayt ochiq.</b> Havolani bilgan har kim shajarani koʻra oladi. Haqiqiy oilaviy maʼlumotlar uchun koʻrish parolini qoʻyish tavsiya etiladi.</p>`}
      <div class="fields" style="max-width:520px"><label class="f"><span>${locked ? "Yangi koʻrish paroli" : "Koʻrish paroli (qarindoshlarga beriladi)"}</span><input id="vpw" type="text" autocomplete="off" placeholder="kamida 4 belgi"></label>
        <div class="row"><button class="btn primary" id="vSet">${I.lock}${locked ? "Parolni almashtirish" : "Parol bilan yopish"}</button>${locked ? `<button class="btn" id="vOpen">Hammaga ochish</button>` : ""}</div>
        <p class="help">Parol almashtirilsa, eski parol bilan kirgan qurilmalar qaytadan parol soʻraydi. Admin panelga kirgan siz har doim koʻrasiz.</p></div></section>
    <div class="two">
      <section class="panel"><h2>Tirik insonlar</h2><p class="sub">Mehmonlardan yashiriladi (siz admin sifatida hammasini koʻrasiz)</p>
        ${PRIV.map(([k, t, sub]) => `<label class="sw"><span class="t"><b>${esc(t)}</b>${sub ? `<small>${esc(sub)}</small>` : ""}</span><input type="checkbox" data-p="${k}"${s.privacy[k] ? " checked" : ""}></label>`).join("")}</section>
      <div class="stack">
        <section class="panel"><h2>Qidiruv tizimlari</h2>
          <label class="sw"><span class="t"><b>Google va boshqalar indekslamasin</b><small>Yoqilgan boʻlsa, sayt qidiruv natijalarida chiqmaydi</small></span><input type="checkbox" data-p="noindex"${s.privacy.noindex ? " checked" : ""}></label></section>
        <section class="panel"><h2>Mehmonlar uchun yuklab olish</h2>
          <label class="sw"><span class="t"><b>Zaxira (JSON) faylini yuklab olish</b><small>Mehmon saytning ochiq qismini fayl sifatida olishi mumkin</small></span><input type="checkbox" id="fBk"${s.features.backup ? " checked" : ""}></label></section>
        <section class="panel"><h2>Alohida insonlar</h2><p class="sub">Har bir insonni sahifasida «Saytda koʻrsatilsin» orqali butunlay yashirish mumkin.</p>
          <a class="btn sm" href="#/people?f=hidden">Yashirin insonlar: ${hidden}</a></section>
      </div>
    </div></div>`;
  const upd = saveBar(() => JSON.stringify(s.privacy) + s.features.backup !== orig, () => saveSettings(s, "Maxfiylik sozlamalari saqlandi"));
  $$("[data-p]").forEach(el => el.onchange = () => { s.privacy[el.dataset.p] = el.checked; upd(); });
  $("#fBk").onchange = e => { s.features.backup = e.target.checked; upd(); };
  $("#vSet").onclick = async () => {
    const pw = $("#vpw").value.trim(); if (pw.length < 4) { toast("Parol kamida 4 belgi boʻlsin", true); $("#vpw").focus(); return; }
    try { await api("/api/view-password", { method: "POST", json: { password: pw } }); await reload(); toast(locked ? "Koʻrish paroli almashtirildi" : "Sayt parol bilan yopildi"); route(); } catch (e) { toast(e.message, true); }
  };
  if ($("#vOpen")) $("#vOpen").onclick = async () => {
    if (!(await confirmDlg({ title: "Sayt hammaga ochilsinmi?", text: "Havolani bilgan har kim parolsiz koʻra oladi.", ok: "Ha, ochilsin" }))) return;
    try { await api("/api/view-password", { method: "POST", json: { password: null } }); await reload(); toast("Sayt ochildi"); route(); } catch (e) { toast(e.message, true); }
  };
}

/* ================= Page: Backup & import ================= */
function toCsv() {
  const q = s => `"${String(s ?? "").replace(/"/g, '""')}"`;
  const head = ["ID", "Familiya", "Ism", "Otasining ismi", "Jinsi", "Tugʻilgan sana", "Tugʻilgan joyi", "Vafot etgan", "Vafot sanasi", "Dafn joyi", "Kasbi", "Ota", "Ona", "Turmush oʻrtogʻi", "Saytda", "Tarjimai hol", "Izoh"];
  const rows = [...A.people.values()].sort((a, b) => bKey(a) - bKey(b)).map(p => [p.id, p.lastName, p.firstName, p.patronymic, p.gender === "f" ? "Ayol" : "Erkak", p.birthDate, p.birthPlace, isDead(p) ? "ha" : "", p.deathDate, p.burialPlace, p.occupation,
    P(p.fatherId) ? short(P(p.fatherId)) : "", P(p.motherId) ? short(P(p.motherId)) : "", spousesOf(p).map(short).join("; "), p.hidden ? "yashirin" : "ha", p.bio, p.privateNote]);
  return "﻿" + [head, ...rows].map(r => r.map(q).join(";")).join("\r\n") + "\r\n";
}
function pageBackup() {
  const ph = A.photos, au = A.auth;
  $("#main").innerHTML = `<div class="wrap">
    ${header("Zaxira va import", "Maʼlumotlarni yuklab olish, tiklash va tozalash")}
    <div class="two">
      <section class="panel"><h2>Zaxira nusxa</h2><p class="sub">Butun shajara bitta faylda: insonlar, sozlamalar va suratlar</p>
        <div class="row"><button class="btn gold" id="bkFull">${I.download}Toʻliq zaxira (suratlar bilan)</button><button class="btn" id="bkLite">${I.download}Suratlarsiz</button></div>
        <p class="help" style="margin-top:10px">Parollar zaxiraga kirmaydi. Faylni xavfsiz joyda saqlang — unda shaxsiy maʼlumotlar bor.</p>
        <p class="note ${au.backupToken ? "good" : ""}" style="margin-top:12px">${au.backupToken ? "Haftalik avtomatik zaxira (GitHub Actions) uchun <b>BACKUP_TOKEN</b> oʻrnatilgan." : "Haftalik avtomatik zaxira sozlanmagan. Yoqish uchun README dagi «Haftalik avtomatik zaxira» boʻlimiga qarang."}</p></section>
      <section class="panel"><h2>Excel uchun roʻyxat</h2><p class="sub">Barcha insonlar CSV jadvalda (Excel va Google Sheets ochadi)</p>
        <button class="btn" id="csv">${I.download}CSV yuklab olish</button></section>
    </div>
    <section class="panel"><h2>Zaxiradan tiklash</h2><p class="sub">Avval yuklab olingan .json faylni tanlang (eski versiya zaxiralari ham mos keladi)</p>
      <label class="btn file-btn">${I.upload}Faylni tanlash<input type="file" id="rsFile" accept="application/json,.json"></label>
      <div id="rsBox" style="margin-top:14px"></div></section>
    <section class="panel"><h2>Suratlar ombori</h2><p class="sub">Suratlar Cloudflare D1 bazasida saqlanadi (bepul tarifda 5 GB)</p>
      <div class="tiles" style="margin-bottom:14px"><div class="tile"><b>${ph.count}</b><span>surat</span></div><div class="tile"><b>${esc(kb(ph.bytes))}</b><span>umumiy hajm</span></div><div class="tile"><b>${ph.orphans}</b><span>ishlatilmagan</span></div></div>
      <button class="btn" id="clean"${ph.orphans ? "" : " disabled"}>${I.trash}Ishlatilmagan suratlarni oʻchirish</button></section>
    <section class="panel danger-zone"><h2>Xavfli hudud</h2><p class="sub">Barcha insonlarni oʻchirish. Avval zaxira yuklab oling!</p>
      <button class="btn danger" id="wipe">${I.trash}Barcha insonlarni oʻchirish…</button></section>
  </div>`;
  const getBackup = async photos => {
    const r = await fetch("/api/backup" + (photos ? "" : "?photos=0"), { headers: { "x-sj": "1" }, credentials: "same-origin" });
    if (!r.ok) throw new Error("Zaxirani olib boʻlmadi");
    download(`shajara-zaxira-${today()}${photos ? "" : "-suratsiz"}.json`, await r.blob(), "application/json");
  };
  $("#bkFull").onclick = () => getBackup(true).then(() => toast("Zaxira yuklab olindi")).catch(e => toast(e.message, true));
  $("#bkLite").onclick = () => getBackup(false).then(() => toast("Zaxira yuklab olindi")).catch(e => toast(e.message, true));
  $("#csv").onclick = () => { download(`shajara-royxat-${today()}.csv`, toCsv(), "text/csv;charset=utf-8"); toast("CSV yuklab olindi"); };
  $("#clean").onclick = async () => {
    try { const r = await api("/api/photos/cleanup", { method: "POST" }); await reload(); toast(`${r.n} ta surat oʻchirildi`); route(); } catch (e) { toast(e.message, true); }
  };
  $("#rsFile").onchange = async e => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    let data = null; try { data = JSON.parse(await f.text()); } catch (x) { }
    const box = $("#rsBox");
    const ok = data && data.app === "shajara" && Array.isArray(data.people) && data.people.every(p => p && typeof p.id === "string");
    if (!ok) { box.innerHTML = `<p class="note bad">Bu fayl shajara zaxirasi emas.</p>`; return; }
    const photos = Array.isArray(data.photos) ? data.photos.filter(x => x && /^[a-f0-9]{32}$/.test(x.id) && x.b64) : [];
    box.innerHTML = `<div class="note warn"><b>${data.people.length} kishi</b>${photos.length ? `, <b>${photos.length} surat</b>` : ""}${data.meta?.title ? ` · «${esc(data.meta.title)}»` : ""}${data.exportedAt ? ` · ${esc(String(data.exportedAt).slice(0, 10))}` : ""}</div>
      <div class="radios" style="margin:12px 0"><label><input type="radio" name="rsm" value="merge" checked> Qoʻshish va yangilash</label><label><input type="radio" name="rsm" value="replace"> Hozirgilarni oʻchirib, toʻliq almashtirish</label></div>
      <div class="row"><button class="btn danger solid" id="rsGo">Tiklash</button><button class="btn" id="rsNo">Bekor qilish</button></div>
      <div class="progress" id="rsProg" hidden style="margin-top:12px"><i></i></div><p class="help" id="rsMsg"></p>`;
    $("#rsNo").onclick = () => box.innerHTML = "";
    $("#rsGo").onclick = async () => {
      const mode = $("input[name=rsm]:checked").value;
      if (mode === "replace" && !(await confirmDlg({ title: "Toʻliq almashtirilsinmi?", text: `Hozirgi ${A.people.size} kishi oʻchiriladi va zaxiradagi ${data.people.length} kishi yoziladi.`, ok: "Ha, almashtirilsin", danger: true }))) return;
      $("#rsGo").disabled = true; $("#rsProg").hidden = false; const bar = $("#rsProg i");
      try {
        $("#rsMsg").textContent = "Insonlar yozilmoqda…";
        await api("/api/restore", { method: "POST", json: { app: "shajara", mode, meta: data.meta, people: data.people } });
        bar.style.width = "20%";
        for (let i = 0; i < photos.length; i++) {
          $("#rsMsg").textContent = `Suratlar: ${i + 1} / ${photos.length}`;
          await api("/api/photos/" + photos[i].id, { method: "PUT", json: { type: photos[i].type, b64: photos[i].b64 } });
          bar.style.width = (20 + 80 * (i + 1) / photos.length) + "%";
        }
        bar.style.width = "100%"; await reload(); toast(`Tiklandi: ${data.people.length} kishi`); route();
      } catch (x) { $("#rsMsg").textContent = "Xato: " + x.message; $("#rsGo").disabled = false; }
    };
  };
  $("#wipe").onclick = async () => {
    const { el, close } = openModal(`<div class="dlg-h"><h2>Hammasini oʻchirish</h2><button class="icon-btn" data-close aria-label="Yopish">${I.x}</button></div>
      <div class="dlg-b"><p style="margin:0">${A.people.size} kishi butunlay oʻchiriladi. Sozlamalar saqlanib qoladi.</p>
        <label class="check"><input type="checkbox" id="wPh"> Suratlarni ham oʻchirish</label>
        <label class="f"><span>Tasdiqlash uchun <b>OʻCHIRISH</b> deb yozing</span><input class="in" id="wTxt" autocomplete="off"></label></div>
      <div class="dlg-f"><button class="btn" data-close>Bekor qilish</button><button class="btn danger solid" id="wGo" disabled>Oʻchirish</button></div>`);
    const nrm = s => s.trim().toUpperCase().replace(/[ʻʼ‘’`']/g, "'");
    $("#wTxt", el).oninput = e => $("#wGo", el).disabled = nrm(e.target.value) !== "O'CHIRISH";
    $("#wGo", el).onclick = async () => {
      try { await api("/api/wipe", { method: "POST", json: { confirm: "O'CHIRISH", photos: $("#wPh", el).checked } }); close(); await reload(); toast("Barcha insonlar oʻchirildi"); route(); }
      catch (e) { toast(e.message, true); }
    };
  };
}

/* ================= Page: Security ================= */
async function pageSecurity() {
  const au = A.auth;
  $("#main").innerHTML = `<div class="wrap">
    ${header("Xavfsizlik", "Admin paroli, kirish seanslari va kirishlar tarixi")}
    <div class="two">
      <section class="panel"><h2>Admin paroli</h2>
        <p class="note ${au.ownPassword ? "good" : "warn"}" style="margin:8px 0 16px">${au.ownPassword ? "Parol shu panel orqali oʻrnatilgan. Cloudflare dagi ADMIN_PASSWORD endi ishlamaydi." : "Hozir Cloudflare dagi <b>ADMIN_PASSWORD</b> ishlatilmoqda. Shu yerda yangi parol oʻrnating — u xavfsiz shifrlangan holda bazada saqlanadi."}</p>
        <form class="fields" id="pwF" novalidate>
          <label class="f"><span>Joriy parol</span><input type="password" id="pw0" autocomplete="current-password"></label>
          <label class="f"><span>Yangi parol</span><input type="password" id="pw1" autocomplete="new-password" placeholder="kamida 10 belgi"></label>
          <label class="f"><span>Yangi parol (takror)</span><input type="password" id="pw2" autocomplete="new-password"></label>
          <p class="err" id="pwE" hidden></p>
          <div><button class="btn primary" id="pwGo">Parolni oʻzgartirish</button></div>
        </form></section>
      <div class="stack">
        <section class="panel"><h2>Kirish seanslari</h2><p class="sub">Admin panelga kirilgan qurilma 180 kun eslab qoladi</p>
          <button class="btn" id="revoke">${I.out}Boshqa barcha qurilmalardan chiqarish</button>
          <p class="help" style="margin-top:8px">Telefon yoki kompyuter yoʻqolsa, shu tugmani bosing. Parol oʻzgartirilganda bu avtomatik bajariladi.</p></section>
        <section class="panel"><h2>Soʻnggi kirishlar</h2><div class="feed" id="logins"><p class="muted">Yuklanmoqda…</p></div></section>
      </div>
    </div></div>`;
  $("#pwF").onsubmit = async e => {
    e.preventDefault(); const E = $("#pwE"); E.hidden = true;
    const a = $("#pw0").value, b = $("#pw1").value, c = $("#pw2").value;
    if (b.length < 10) { E.textContent = "Yangi parol kamida 10 belgi boʻlsin."; E.hidden = false; return; }
    if (b !== c) { E.textContent = "Yangi parollar bir xil emas."; E.hidden = false; return; }
    $("#pwGo").disabled = true;
    try { await api("/api/password", { method: "POST", json: { current: a, next: b } }); await reload(); toast("Parol oʻzgartirildi"); route(); }
    catch (x) { E.textContent = x.message; E.hidden = false; $("#pwGo").disabled = false; }
  };
  $("#revoke").onclick = async () => {
    if (!(await confirmDlg({ title: "Boshqa qurilmalardan chiqarilsinmi?", text: "Bu qurilmadan tashqari hamma joyda admin panelga qayta kirish kerak boʻladi.", ok: "Ha, chiqarilsin" }))) return;
    try { await api("/api/sessions/revoke", { method: "POST" }); toast("Boshqa qurilmalardan chiqarildi"); } catch (e) { toast(e.message, true); }
  };
  try {
    const { log } = await api("/api/log?limit=500");
    const rows = log.filter(r => r.action === "login" || r.action === "login_fail").slice(0, 15);
    if ($("#logins")) $("#logins").innerHTML = rows.length ? rows.map(feedRow).join("") : `<p class="muted">Maʼlumot yoʻq.</p>`;
  } catch (e) { }
}

/* ================= Page: Log ================= */
async function pageLog() {
  const F = [["all", "Hammasi"], ["people", "Insonlar"], ["settings", "Sozlamalar"], ["security", "Xavfsizlik"], ["login", "Kirishlar"]];
  const match = { all: () => true, people: r => ["create", "update", "delete", "restore", "wipe"].includes(r.action), settings: r => ["settings", "photos"].includes(r.action), security: r => r.action === "security", login: r => r.action.startsWith("login") };
  let f = "all", rows = [];
  $("#main").innerHTML = `<div class="wrap">${header("Oʻzgarishlar tarixi", "Soʻnggi 1000 ta amal: kim qoʻshildi, nima oʻzgardi, kim kirdi")}
    <div class="seg" id="lf">${F.map(([k, l]) => `<button data-f="${k}" aria-pressed="${k === f}">${l}</button>`).join("")}</div>
    <div class="panel flush"><div class="tbl-scroll"><table><thead><tr><th style="width:170px">Vaqt</th><th style="width:130px">Amal</th><th>Tavsif</th></tr></thead><tbody id="lb"><tr><td colspan="3" class="muted">Yuklanmoqda…</td></tr></tbody></table></div></div></div>`;
  const draw = () => {
    const list = rows.filter(match[f]);
    $("#lb").innerHTML = list.length ? list.map(r => { const p = r.target && P(r.target);
      return `<tr><td class="muted">${esc(fmtTime(r.at))}</td><td>${actBadge(r.action)}</td><td>${p ? `<a href="#/people/${encodeURIComponent(p.id)}">${esc(r.summary)}</a>` : esc(r.summary || "")}</td></tr>`; }).join("")
      : `<tr><td colspan="3" class="empty">Yozuv yoʻq.</td></tr>`;
  };
  $$("#lf [data-f]").forEach(b => b.onclick = () => { f = b.dataset.f; $$("#lf [data-f]").forEach(x => x.setAttribute("aria-pressed", x === b)); draw(); });
  try { rows = (await api("/api/log?limit=1000")).log; draw(); } catch (e) { $("#lb").innerHTML = `<tr><td colspan="3" class="err">${esc(e.message)}</td></tr>`; }
}

start();
