// Kirish nuqtasi.
//   /            → public/index.html + sayt sozlamalari (sarlavha, ranglar, ma'lumotlar) serverda qo'shiladi
//   /api/*       → API (src/api.js)
//   /_blob/<id>  → suratlar
//   /robots.txt  → sozlamaga qarab
//   qolgani      → public/ papkadagi statik fayllar (/admin → public/admin.html)
import { onRequest as api, init, whoIs, loadSettings, publicPeople, publicSettings } from "./api.js";
import { onRequestGet as blob } from "./blob.js";
import "../public/config.js";
const C = globalThis.SJ_CONFIG;

async function page(request, env) {
  const res = await env.ASSETS.fetch(request);
  if (!res.ok || !(res.headers.get("content-type") || "").includes("text/html")) return res;
  let s, boot;
  try {
    await init(env);
    const w = await whoIs(request, env);
    s = await loadSettings(env);
    if (!w.viewOk) boot = { status: 401, body: { locked: true, title: s.title } };
    else {
      const preview = new URL(request.url).searchParams.get("preview") === "visitor";
      const asAdmin = w.admin && !preview;
      const rows = (await env.DB.prepare("SELECT id, data, updated FROM people").all()).results || [];
      let rev = 0; const map = new Map();
      for (const r of rows) { rev = Math.max(rev, r.updated); map.set(r.id, JSON.parse(r.data)); }
      boot = { status: 200, body: { people: publicPeople(map, s, asAdmin), settings: publicSettings(s, asAdmin), rev, admin: w.admin } };
    }
  } catch (e) {
    return res; // baza ishlamasa — sahifa o'zi /api/public orqali urinib ko'radi
  }
  const title = s.title || (s.labels && s.labels.defTitle) || C.LABELS.defTitle;
  const css = C.themeCss(s);
  const data = JSON.stringify(boot).replace(/</g, "\\u003c");
  const out = new HTMLRewriter()
    .on("html", { element(el) { if (s.theme.mode !== "auto") el.setAttribute("data-theme", s.theme.mode); } })
    .on("title", { element(el) { el.setInnerContent(title); } })
    .on('meta[name="description"]', { element(el) { el.setAttribute("content", s.description || ""); } })
    .on('meta[name="robots"]', { element(el) { if (!s.privacy.noindex) el.remove(); } })
    .on("head", { element(el) {
      if (css) el.append(`<style id="sjTheme">${css}</style>`, { html: true });
      el.append(`<script id="sjBoot" type="application/json">${data}</script>`, { html: true });
    } })
    .transform(res);
  const h = new Headers(out.headers);
  h.set("cache-control", "no-store");
  h.delete("etag");
  return new Response(out.body, { status: out.status, headers: h });
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname === "/api" || url.pathname.startsWith("/api/")) {
      const path = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);
      return api({ request, env, params: { path }, waitUntil: ctx.waitUntil.bind(ctx) });
    }
    if (url.pathname.startsWith("/_blob/")) {
      if (request.method !== "GET" && request.method !== "HEAD") return new Response("Method not allowed", { status: 405 });
      return blob({ request, env, params: { id: url.pathname.slice(7) } });
    }
    if (url.pathname === "/robots.txt") {
      let noindex = true;
      try { await init(env); noindex = (await loadSettings(env)).privacy.noindex; } catch (e) {}
      return new Response(noindex ? "User-agent: *\nDisallow: /\n" : "User-agent: *\nDisallow: /admin\nDisallow: /api/\n", { headers: { "content-type": "text/plain; charset=utf-8" } });
    }
    if (url.pathname === "/" || url.pathname === "/index.html") return page(request, env);
    return env.ASSETS.fetch(request);
  }
};
