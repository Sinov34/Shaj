// Shajara API — Cloudflare Worker + D1.
// Sozlash (Cloudflare → Worker → Settings → Variables and Secrets):
//   • D1 binding:  DB  (wrangler.jsonc da)
//   • Secret:      ADMIN_PASSWORD  → birinchi kirish paroli (keyin admin paneldan o'zgartiriladi)
//   • Secret:      BACKUP_TOKEN    → ixtiyoriy, GitHub haftalik zaxirasi uchun
import "../public/config.js";
const C = globalThis.SJ_CONFIG;

const ID_RE = /^[A-Za-z0-9_\-.~:@+]{1,200}$/;
const PID = /^[a-f0-9]{32}$/;
const MAX_DOC = 256 * 1024;
const MAX_RESTORE = 8 * 1024 * 1024;
const MAX_PHOTO = 1400 * 1024;           // D1 qatori 2 MB dan oshmasligi uchun (base64 bilan)
const PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp"];
const COOKIE = "sj_s", VCOOKIE = "sj_v";
const SESSION_DAYS = 180, VIEW_DAYS = 365;
const PBKDF2_ITER = 10000;               // Workers bepul tarifining CPU chegarasi uchun
const LOG_KEEP = 1000;

const json = (obj, status = 200, headers = {}) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers } });
const fail = (status, message, extra = {}) => json({ error: message, ...extra }, status);
const err = (status, message) => Object.assign(new Error(message), { status });

/* ---------- database ---------- */
let ready = null;
export function init(env) {
  if (!env.DB) throw new Error("D1 bazasi ulanmagan: Settings → Bindings → D1 → nomi DB");
  if (!ready) ready = env.DB.batch([
    env.DB.prepare("CREATE TABLE IF NOT EXISTS people (id TEXT PRIMARY KEY, data TEXT NOT NULL, updated INTEGER NOT NULL)"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, data TEXT NOT NULL)"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS photos (id TEXT PRIMARY KEY, type TEXT NOT NULL, b64 TEXT NOT NULL, created INTEGER NOT NULL)"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS log (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL, action TEXT NOT NULL, target TEXT, summary TEXT)"),
  ]).catch(e => { ready = null; throw e; });
  return ready;
}
async function metaGet(env, k) { const r = await env.DB.prepare("SELECT data FROM meta WHERE k = ?").bind(k).first(); return r ? JSON.parse(r.data) : null; }
const metaPut = (env, k, v) => env.DB.prepare("INSERT INTO meta (k, data) VALUES (?1, ?2) ON CONFLICT(k) DO UPDATE SET data = ?2").bind(k, JSON.stringify(v));
export async function loadSettings(env) { return C.settingsOf(await metaGet(env, "info")); }
async function loadPeople(env) {
  const rows = (await env.DB.prepare("SELECT id, data, updated FROM people").all()).results || [];
  let rev = 0; const map = new Map(), upd = new Map();
  for (const r of rows) { rev = Math.max(rev, r.updated); map.set(r.id, JSON.parse(r.data)); upd.set(r.id, r.updated); }
  return { map, rev, upd };
}
async function log(env, action, target, summary) {
  try {
    await env.DB.batch([
      env.DB.prepare("INSERT INTO log (at, action, target, summary) VALUES (?, ?, ?, ?)").bind(Date.now(), action, target || null, (summary || "").slice(0, 300)),
      env.DB.prepare("DELETE FROM log WHERE id <= (SELECT MAX(id) - ? FROM log)").bind(LOG_KEEP),
    ]);
  } catch (e) { /* jurnal ixtiyoriy */ }
}

/* ---------- crypto helpers ---------- */
const enc = new TextEncoder();
const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
const unhex = s => new Uint8Array((s.match(/../g) || []).map(h => parseInt(h, 16)));
const randomHex = (n = 16) => hex(crypto.getRandomValues(new Uint8Array(n)));
async function hmac(secret, msg) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, enc.encode(msg)));
}
async function pbkdf2(pw, salt, iter = PBKDF2_ITER) {
  const key = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: unhex(salt), iterations: iter }, key, 256));
}
function safeEq(a, b) { a = String(a); b = String(b); if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
function readCookie(req, name) {
  const c = req.headers.get("cookie") || "";
  for (const part of c.split(/;\s*/)) { const i = part.indexOf("="); if (i > 0 && part.slice(0, i) === name) return part.slice(i + 1); }
  return null;
}
const secureFlag = req => new URL(req.url).protocol === "https:" ? "; Secure" : "";
const cookie = (req, name, val, days) => `${name}=${val}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.round(days * 86400)}${secureFlag(req)}`;

/* ---------- auth ---------- */
// meta 'auth' = { secret, hash?, salt?, iter?, viewHash?, viewSalt? }  — zaxiraga kirmaydi.
export async function getAuth(env) {
  let a = await metaGet(env, "auth");
  if (!a || !a.secret) { a = { ...(a || {}), secret: randomHex(32) }; await metaPut(env, "auth", a).run(); }
  return a;
}
async function checkCookie(req, a, name, prefix) {
  const v = readCookie(req, name); if (!v) return false;
  const [exp, sig] = v.split(".");
  if (!exp || !sig || +exp < Date.now()) return false;
  return safeEq(sig, await hmac(a.secret, prefix + exp));
}
const viewPrefix = a => "view." + String(a.viewHash || "").slice(0, 16) + ".";
export async function whoIs(req, env) {
  const a = await getAuth(env);
  const admin = await checkCookie(req, a, COOKIE, "admin.");
  const locked = !!a.viewHash;
  const viewOk = admin || !locked || await checkCookie(req, a, VCOOKIE, viewPrefix(a));
  return { a, admin, locked, viewOk, configured: !!(a.hash || env.ADMIN_PASSWORD) };
}
async function adminCookie(req, a) { const exp = Date.now() + SESSION_DAYS * 864e5; return cookie(req, COOKIE, exp + "." + await hmac(a.secret, "admin." + exp), SESSION_DAYS); }
async function checkAdminPassword(env, a, pw) {
  if (typeof pw !== "string" || !pw) return false;
  if (a.hash) return safeEq(await pbkdf2(pw, a.salt, a.iter || PBKDF2_ITER), a.hash);
  if (env.ADMIN_PASSWORD) return safeEq(await hmac("cmp", pw), await hmac("cmp", env.ADMIN_PASSWORD));
  return false;
}

/* ---------- people: validation, privacy ---------- */
const str = (v, n) => (typeof v === "string" ? v : "").slice(0, n).trim();
const idOrNull = v => (typeof v === "string" && ID_RE.test(v) ? v : null);
function cleanPerson(b, id) {
  const sp = Array.isArray(b.spouses) ? [...new Set(b.spouses.map(idOrNull).filter(x => x && x !== id))].slice(0, 30) : [];
  const fa = idOrNull(b.fatherId), mo = idOrNull(b.motherId);
  return {
    firstName: str(b.firstName, 120), lastName: str(b.lastName, 120), patronymic: str(b.patronymic, 160),
    gender: b.gender === "f" ? "f" : "m",
    birthDate: str(b.birthDate, 24), birthPlace: str(b.birthPlace, 200),
    deathDate: str(b.deathDate, 24), deceased: !!b.deceased || !!str(b.deathDate, 24), burialPlace: str(b.burialPlace, 200),
    occupation: str(b.occupation, 200), bio: str(b.bio, 20000),
    photoId: PID.test(b.photoId || "") ? b.photoId : null,
    photo: typeof b.photo === "string" && /^data:image\/(jpeg|png|webp);base64,/.test(b.photo) && b.photo.length < 400000 ? b.photo : null,
    fatherId: fa === id ? null : fa, motherId: mo === id ? null : mo, spouses: sp,
    hidden: !!b.hidden, privateNote: str(b.privateNote, 5000),
    createdAt: Number.isFinite(b.createdAt) ? b.createdAt : Date.now()
  };
}
const yearOnly = s => { const m = String(s || "").match(/(\d{4})/); return m ? m[1] : ""; };
const isLiving = p => !p.deceased && !p.deathDate;
export function publicPeople(map, s, admin) {
  const hidden = new Set(); if (!admin) for (const [id, p] of map) if (p.hidden) hidden.add(id);
  const out = [];
  for (const [id, p0] of map) {
    if (hidden.has(id)) continue;
    const p = { id, ...p0 };
    if (admin) { out.push(p); continue; }
    delete p.privateNote; delete p.hidden;
    if (hidden.has(p.fatherId)) p.fatherId = null;
    if (hidden.has(p.motherId)) p.motherId = null;
    p.spouses = (p.spouses || []).filter(x => !hidden.has(x));
    if (isLiving(p)) {
      const pr = s.privacy;
      if (pr.birthDay) p.birthDate = yearOnly(p.birthDate);
      if (pr.birthPlace) p.birthPlace = "";
      if (pr.photo) { p.photoId = null; p.photo = null; }
      if (pr.occupation) p.occupation = "";
      if (pr.bio) p.bio = "";
    }
    out.push(p);
  }
  return out;
}
export function publicSettings(s, admin) { const o = JSON.parse(JSON.stringify(s)); if (!admin) o.meId = null; return o; }
const nameOf = p => [p.lastName, p.firstName].filter(Boolean).join(" ") || "(ismsiz)";

/* ---------- settings validation ---------- */
function cleanSettings(input) {
  const D = C.DEFAULTS;
  function walk(def, val, path) {
    if (path === "labels") {
      const o = {}; if (val && typeof val === "object") for (const k of Object.keys(val)) if (C.LABELS[k] !== undefined && typeof val[k] === "string" && val[k].trim() && val[k] !== C.LABELS[k]) o[k] = val[k].slice(0, 3000);
      return o;
    }
    if (path === "theme.light" || path === "theme.dark") {
      const o = {}; if (val && typeof val === "object") for (const [k] of C.COLORS) if (/^#[0-9a-fA-F]{6}$/.test(val[k] || "")) o[k] = val[k].toUpperCase();
      return o;
    }
    if (C.ENUMS[path]) return C.ENUMS[path].includes(val) ? val : def;
    if (def && typeof def === "object") { const o = {}; for (const k of Object.keys(def)) o[k] = walk(def[k], val && typeof val === "object" ? val[k] : undefined, path ? path + "." + k : k); return o; }
    if (typeof def === "boolean") return typeof val === "boolean" ? val : def;
    if (typeof def === "number") { const n = Math.round(Number(val)); return Number.isFinite(n) ? Math.min(365, Math.max(1, n)) : def; }
    if (typeof def === "string") return typeof val === "string" ? val.slice(0, path === "description" ? 300 : 200).trim() : def;
    if (def === null) { // id fields
      if (/photoId$/i.test(path)) return PID.test(val || "") ? val : null;
      return idOrNull(val);
    }
    return def;
  }
  return walk(D, input || {}, "");
}
const settingPhotoIds = s => [s.scene && s.scene.photoId, s.logoPhotoId].filter(x => PID.test(x || ""));

/* ---------- body readers ---------- */
async function readJson(req, max = MAX_DOC) {
  const len = +(req.headers.get("content-length") || 0);
  if (len > max) throw err(413, "Juda katta");
  const txt = await req.text();
  if (txt.length > max) throw err(413, "Juda katta");
  const v = JSON.parse(txt);
  if (!v || typeof v !== "object" || Array.isArray(v)) throw err(400, "Obyekt kutilgan");
  return v;
}
function b64FromBuf(buf) { let s = ""; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }

/* ---------- photo housekeeping ---------- */
async function usedPhotoIds(env, map) {
  const used = new Set(settingPhotoIds(await loadSettings(env)));
  for (const p of (map || (await loadPeople(env)).map).values()) if (p.photoId) used.add(p.photoId);
  return used;
}
async function dropPhotosIfUnused(env, ids) {
  ids = ids.filter(x => PID.test(x || "")); if (!ids.length) return;
  const used = await usedPhotoIds(env);
  const gone = ids.filter(x => !used.has(x));
  if (gone.length) await env.DB.batch(gone.map(x => env.DB.prepare("DELETE FROM photos WHERE id = ?").bind(x)));
}

/* ---------- writes with relationship integrity ---------- */
const putStmt = (env, id, data, now) => env.DB.prepare("INSERT INTO people (id, data, updated) VALUES (?1, ?2, ?3) ON CONFLICT(id) DO UPDATE SET data = ?2, updated = ?3").bind(id, JSON.stringify(data), now);
async function savePerson(env, id, data, map) {
  const now = Date.now(), old = map.get(id), stmts = [putStmt(env, id, data, now)];
  const prevSp = old ? old.spouses || [] : [];
  for (const s of data.spouses) { const q = map.get(s); if (q && !(q.spouses || []).includes(id)) stmts.push(putStmt(env, s, { ...q, spouses: [...(q.spouses || []), id] }, now)); }
  for (const s of prevSp) if (!data.spouses.includes(s)) { const q = map.get(s); if (q) stmts.push(putStmt(env, s, { ...q, spouses: (q.spouses || []).filter(x => x !== id) }, now)); }
  await env.DB.batch(stmts);
  if (old && old.photoId && old.photoId !== data.photoId) await dropPhotosIfUnused(env, [old.photoId]);
  return old;
}
async function deletePeople(env, ids, map) {
  const del = new Set(ids.filter(x => map.has(x))); if (!del.size) return 0;
  const now = Date.now(), stmts = [];
  for (const [id, q] of map) {
    if (del.has(id)) continue;
    const patch = {};
    if (del.has(q.fatherId)) patch.fatherId = null;
    if (del.has(q.motherId)) patch.motherId = null;
    if ((q.spouses || []).some(x => del.has(x))) patch.spouses = q.spouses.filter(x => !del.has(x));
    if (Object.keys(patch).length) stmts.push(putStmt(env, id, { ...q, ...patch }, now));
  }
  for (const id of del) stmts.push(env.DB.prepare("DELETE FROM people WHERE id = ?").bind(id));
  for (let i = 0; i < stmts.length; i += 80) await env.DB.batch(stmts.slice(i, i + 80));
  const photos = [...del].map(id => map.get(id).photoId).filter(Boolean);
  for (const id of del) map.delete(id);
  await dropPhotosIfUnused(env, photos);
  return del.size;
}

/* ---------- main handler ---------- */
export async function onRequest(ctx) {
  const { request: req, env, params } = ctx;
  const seg = [].concat(params.path || []);
  const method = req.method, url = new URL(req.url);
  const route = method + " /" + seg.join("/");
  try {
    await init(env);
    const W = await whoIs(req, env), { a, admin } = W;
    const mutating = method !== "GET" && method !== "HEAD";
    if (mutating && req.headers.get("x-sj") !== "1") return fail(400, "Bad request");

    /* --- public --- */
    if (route === "GET /me") return json({ admin, configured: W.configured, locked: W.locked, viewOk: W.viewOk });

    if (route === "GET /public") {
      if (!W.viewOk) { const s = await loadSettings(env); return fail(401, "Yopiq", { locked: true, title: s.title }); }
      const s = await loadSettings(env), { map, rev } = await loadPeople(env);
      const asAdmin = admin && url.searchParams.get("preview") !== "visitor";
      return json({ people: publicPeople(map, s, asAdmin), settings: publicSettings(s, asAdmin), rev, admin });
    }

    if (route === "POST /view-login") {
      const { password } = await readJson(req);
      if (!a.viewHash) return json({ ok: true });
      const ok = typeof password === "string" && safeEq(await pbkdf2(password, a.viewSalt), a.viewHash);
      if (!ok) { await new Promise(r => setTimeout(r, 900)); return fail(401, "Parol notoʻgʻri"); }
      const exp = Date.now() + VIEW_DAYS * 864e5;
      return json({ ok: true }, 200, { "set-cookie": cookie(req, VCOOKIE, exp + "." + await hmac(a.secret, viewPrefix(a) + exp), VIEW_DAYS) });
    }

    if (route === "POST /login") {
      if (!W.configured) return fail(503, "ADMIN_PASSWORD oʻrnatilmagan");
      const since = Date.now() - 10 * 60e3;
      const tries = await env.DB.prepare("SELECT COUNT(*) AS n FROM log WHERE action = 'login_fail' AND at > ?").bind(since).first();
      if (tries && tries.n >= 20) return fail(429, "Juda koʻp urinish. 10 daqiqadan soʻng qayta urinib ko'ring.");
      const { password } = await readJson(req);
      const where = (req.cf && req.cf.country) ? "mamlakat: " + req.cf.country : "";
      if (!(await checkAdminPassword(env, a, password))) {
        await log(env, "login_fail", null, "Notoʻgʻri parol bilan kirishga urinish " + where);
        await new Promise(r => setTimeout(r, 1200));
        return fail(401, "Parol notoʻgʻri");
      }
      await log(env, "login", null, "Admin panelga kirildi " + where);
      return json({ admin: true }, 200, { "set-cookie": await adminCookie(req, a) });
    }
    if (route === "POST /logout") return json({ admin: false }, 200, { "set-cookie": cookie(req, COOKIE, "", 0) });

    // GET /backup — toʻliq zaxira. Admin yoki "Authorization: Bearer <BACKUP_TOKEN>"
    if (route === "GET /backup") {
      const auth = req.headers.get("authorization") || "";
      const okToken = env.BACKUP_TOKEN && env.BACKUP_TOKEN.length >= 16 && safeEq(auth, "Bearer " + env.BACKUP_TOKEN);
      if (!admin && !okToken) return fail(403, "Ruxsat yoʻq");
      const rows = (await env.DB.prepare("SELECT id, data FROM people ORDER BY id").all()).results || [];
      const meta = (await metaGet(env, "info")) || {};
      const withPhotos = url.searchParams.get("photos") !== "0";
      const ph = withPhotos ? (await env.DB.prepare("SELECT id, type, b64 FROM photos ORDER BY id").all()).results || [] : [];
      return json({ app: "shajara", version: 3, exportedAt: new Date().toISOString(), meta,
        people: rows.map(r => ({ id: r.id, ...JSON.parse(r.data) })), photos: ph });
    }

    /* --- everything below: admin only --- */
    if (!admin) return fail(403, "Admin panelga kiring");

    if (route === "GET /admin/data") {
      const s = await loadSettings(env), { map, rev, upd } = await loadPeople(env);
      const ph = (await env.DB.prepare("SELECT id, length(b64) AS n FROM photos").all()).results || [];
      const used = new Set(settingPhotoIds(s)); for (const p of map.values()) if (p.photoId) used.add(p.photoId);
      const recent = (await env.DB.prepare("SELECT at, action, target, summary FROM log ORDER BY id DESC LIMIT 8").all()).results || [];
      return json({
        people: [...map].map(([id, p]) => ({ id, ...p, _updated: upd.get(id) })), settings: s, rev,
        photos: { count: ph.length, bytes: Math.round(ph.reduce((t, r) => t + r.n, 0) * 0.75), orphans: ph.filter(r => !used.has(r.id)).length },
        auth: { viewLocked: !!a.viewHash, ownPassword: !!a.hash, envPassword: !!env.ADMIN_PASSWORD, backupToken: !!(env.BACKUP_TOKEN && env.BACKUP_TOKEN.length >= 16) },
        recent
      });
    }

    if (route === "GET /log") {
      const lim = Math.min(1000, Math.max(1, +url.searchParams.get("limit") || 300));
      const rows = (await env.DB.prepare("SELECT id, at, action, target, summary FROM log ORDER BY id DESC LIMIT ?").bind(lim).all()).results || [];
      return json({ log: rows });
    }

    /* people */
    if (seg[0] === "people" && seg.length === 2 && ID_RE.test(seg[1])) {
      const id = seg[1], { map } = await loadPeople(env);
      if (method === "DELETE") {
        const p = map.get(id); if (!p) return fail(404, "Topilmadi");
        await deletePeople(env, [id], map); await log(env, "delete", id, nameOf(p) + " oʻchirildi");
        return json({ ok: true });
      }
      if (method === "PUT" || method === "PATCH") {
        const body = await readJson(req); delete body.id;
        const base = method === "PATCH" ? map.get(id) : null;
        if (method === "PATCH" && !base) return fail(404, "Topilmadi");
        const data = cleanPerson(base ? { ...base, ...body } : body, id);
        if (!data.firstName) return fail(400, "Ism kiritilmagan");
        if (data.fatherId && data.fatherId === data.motherId) data.motherId = null;
        const old = await savePerson(env, id, data, map);
        await log(env, old ? "update" : "create", id, nameOf(data) + (old ? " — maʼlumot yangilandi" : " qoʻshildi"));
        return json({ ok: true, person: { id, ...data } });
      }
    }
    if (route === "POST /people-bulk") {
      const { ids, action } = await readJson(req);
      if (!Array.isArray(ids) || !ids.length || ids.length > 2000) return fail(400, "ids kerak");
      const { map } = await loadPeople(env);
      if (action === "delete") { const n = await deletePeople(env, ids, map); await log(env, "delete", null, `${n} kishi oʻchirildi (guruhli)`); return json({ ok: true, n }); }
      if (action === "hide" || action === "show") {
        const now = Date.now(), st = ids.filter(id => map.has(id)).map(id => putStmt(env, id, { ...map.get(id), hidden: action === "hide" }, now));
        for (let i = 0; i < st.length; i += 80) await env.DB.batch(st.slice(i, i + 80));
        await log(env, "update", null, `${st.length} kishi ${action === "hide" ? "yashirildi" : "koʻrinadigan qilindi"}`);
        return json({ ok: true, n: st.length });
      }
      return fail(400, "Noma'lum amal");
    }

    /* settings */
    if (route === "PUT /settings") {
      const body = await readJson(req), old = await loadSettings(env), next = cleanSettings(body);
      await metaPut(env, "info", next).run();
      const gone = settingPhotoIds(old).filter(x => !settingPhotoIds(next).includes(x));
      if (gone.length) await dropPhotosIfUnused(env, gone);
      await log(env, "settings", null, typeof body._what === "string" ? body._what.slice(0, 120) : "Sozlamalar saqlandi");
      return json({ ok: true, settings: next });
    }

    /* photos */
    if (seg[0] === "photos") {
      if (route === "GET /photos") {
        const rows = (await env.DB.prepare("SELECT id, type, length(b64) AS n, created FROM photos ORDER BY created DESC").all()).results || [];
        const used = await usedPhotoIds(env);
        return json({ photos: rows.map(r => ({ id: r.id, type: r.type, bytes: Math.round(r.n * 0.75), created: r.created, used: used.has(r.id) })) });
      }
      if (route === "POST /photos") {
        const type = (req.headers.get("content-type") || "").split(";")[0].trim();
        if (!PHOTO_TYPES.includes(type)) return fail(415, "Faqat JPG, PNG yoki WEBP");
        const buf = await req.arrayBuffer();
        if (!buf.byteLength || buf.byteLength > MAX_PHOTO) return fail(413, "Surat juda katta (1,4 MB dan oshmasin)");
        const id = randomHex(16);
        await env.DB.prepare("INSERT INTO photos (id, type, b64, created) VALUES (?, ?, ?, ?)").bind(id, type, b64FromBuf(buf), Date.now()).run();
        return json({ id, url: "/_blob/" + id, sizeBytes: buf.byteLength, contentType: type });
      }
      if (route === "POST /photos/cleanup") {
        const used = await usedPhotoIds(env);
        const rows = (await env.DB.prepare("SELECT id FROM photos").all()).results || [];
        const gone = rows.map(r => r.id).filter(x => !used.has(x));
        for (let i = 0; i < gone.length; i += 80) await env.DB.batch(gone.slice(i, i + 80).map(x => env.DB.prepare("DELETE FROM photos WHERE id = ?").bind(x)));
        if (gone.length) await log(env, "photos", null, `${gone.length} ta ishlatilmagan surat oʻchirildi`);
        return json({ ok: true, n: gone.length });
      }
      if (method === "PUT" && seg.length === 2 && PID.test(seg[1])) {
        const len = +(req.headers.get("content-length") || 0);
        if (len > MAX_PHOTO * 1.4 + 200) return fail(413, "Surat juda katta");
        const { type, b64 } = JSON.parse(await req.text());
        if (!PHOTO_TYPES.includes(type) || typeof b64 !== "string" || !/^[A-Za-z0-9+/=]+$/.test(b64) || b64.length > MAX_PHOTO * 1.37) return fail(400, "Surat notoʻgʻri");
        await env.DB.prepare("INSERT OR REPLACE INTO photos (id, type, b64, created) VALUES (?, ?, ?, ?)").bind(seg[1], type, b64, Date.now()).run();
        return json({ ok: true });
      }
      if (method === "DELETE" && seg.length === 2 && PID.test(seg[1])) {
        const r = await env.DB.prepare("DELETE FROM photos WHERE id = ?").bind(seg[1]).run();
        return json({ deleted: !!(r.meta && r.meta.changes) });
      }
    }

    /* restore from backup (people + settings; photos are sent separately via PUT /photos/:id) */
    if (route === "POST /restore") {
      const body = await readJson(req, MAX_RESTORE);
      if (body.app !== "shajara" || !Array.isArray(body.people)) return fail(400, "Bu fayl shajara zaxirasi emas");
      const people = body.people.filter(p => p && typeof p.id === "string" && ID_RE.test(p.id));
      const now = Date.now(), stmts = [];
      if (body.mode === "replace") stmts.push(env.DB.prepare("DELETE FROM people"));
      for (const p of people) { const { id, ...rest } = p; stmts.push(putStmt(env, id, { ...cleanPerson(rest, id), firstName: str(rest.firstName, 120) }, now)); }
      if (body.meta && typeof body.meta === "object" && !Array.isArray(body.meta)) {
        const merged = { ...(await metaGet(env, "info") || {}), ...body.meta };
        stmts.push(metaPut(env, "info", cleanSettings(merged)));
      }
      for (let i = 0; i < stmts.length; i += 80) await env.DB.batch(stmts.slice(i, i + 80));
      await log(env, "restore", null, `Zaxiradan tiklandi: ${people.length} kishi (${body.mode === "replace" ? "toʻliq almashtirish" : "qoʻshish/yangilash"})`);
      return json({ ok: true, n: people.length });
    }

    if (route === "POST /wipe") {
      const { confirm, photos } = await readJson(req);
      if (confirm !== "O'CHIRISH") return fail(400, "Tasdiqlash so'zi notoʻgʻri");
      const st = [env.DB.prepare("DELETE FROM people")];
      if (photos) st.push(env.DB.prepare("DELETE FROM photos"));
      await env.DB.batch(st);
      await log(env, "wipe", null, "Barcha insonlar oʻchirildi" + (photos ? " (suratlar bilan)" : ""));
      return json({ ok: true });
    }

    /* security */
    if (route === "POST /password") {
      const { current, next } = await readJson(req);
      if (!(await checkAdminPassword(env, a, current))) { await new Promise(r => setTimeout(r, 1000)); return fail(401, "Joriy parol notoʻgʻri"); }
      if (typeof next !== "string" || next.length < 10 || next.length > 200) return fail(400, "Yangi parol kamida 10 belgi boʻlsin");
      const salt = randomHex(16), na = { ...a, salt, iter: PBKDF2_ITER, hash: await pbkdf2(next, salt), secret: randomHex(32) };
      await metaPut(env, "auth", na).run();
      await log(env, "security", null, "Admin paroli oʻzgartirildi, boshqa qurilmalardan chiqarildi");
      return json({ ok: true }, 200, { "set-cookie": await adminCookie(req, na) });
    }
    if (route === "POST /sessions/revoke") {
      const na = { ...a, secret: randomHex(32) };
      await metaPut(env, "auth", na).run();
      await log(env, "security", null, "Barcha qurilmalardan chiqarildi");
      return json({ ok: true }, 200, { "set-cookie": await adminCookie(req, na) });
    }
    if (route === "POST /view-password") {
      const { password } = await readJson(req);
      const na = { ...a };
      if (password === null) { delete na.viewHash; delete na.viewSalt; }
      else if (typeof password === "string" && password.length >= 4 && password.length <= 200) { na.viewSalt = randomHex(16); na.viewHash = await pbkdf2(password, na.viewSalt); }
      else return fail(400, "Parol kamida 4 belgi boʻlsin");
      await metaPut(env, "auth", na).run();
      await log(env, "security", null, password === null ? "Sayt hamma uchun ochildi" : "Sayt parol bilan yopildi (ko'rish paroli oʻrnatildi)");
      return json({ ok: true, viewLocked: !!na.viewHash });
    }

    return fail(404, "Not found");
  } catch (e) {
    if (e && e.status) return fail(e.status, e.message);
    if (e instanceof SyntaxError) return fail(400, "JSON notoʻgʻri");
    return fail(500, String((e && e.message) || e));
  }
}
